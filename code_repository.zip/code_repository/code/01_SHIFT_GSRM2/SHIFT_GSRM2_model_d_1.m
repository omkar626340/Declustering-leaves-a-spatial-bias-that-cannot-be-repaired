clear; clc; close all;

% ══════════════════════════════════════════════════════════════════

% SHIFT_GSRM2 MODEL d — Complete faithful translation of SHIFT_GSRM2x.f90
% Bird & Kreemer (2015), Bull. Seismol. Soc. Am., 105(1), 152-166
%
% This implements models b+c+d exactly as in the FORTRAN:
%   Model b: Isotropic Gaussian smoothing of offshore non-SUB strain
%   Model c: Stochastic sandblasting of SUB strain toward outer rise
%   Model d: 5 tectonic zones with zone-specific parameters
%
% FILES REQUIRED:
%   GSRM_average_strain_v2.1-20150901.txt
%   PB2002_tectonic_zones.grd
%   underwater.grd
%   PB2002_pts.csv             (pre-computed internal boundary points)
%   GCMT_clean.csv             (pre-parsed GCMT catalog)
%   1777878572813_shape.shp    (CA study region polygon + .shx .dbf .prj .cpg)

% ══════════════════════════════════════════════════════════════════

s_per_year = 31557600.0;
Moment     = @(m) 10.^(1.5*m + 9.05);
rpd        = pi/180;
R_earth_m  = 6.3712e6;

% ══════════════════════════════════════════════════════════════════
% CALIFORNIA SHAPEFILE CONFIGURATION
% ──────────────────────────────────────────────────────────────────
% To switch shapefiles: change fname_CA_shp to your new .shp file.
% The code uses the shapefile for:
%   1. Polygon boundary overlay on all CA maps
%   2. Point-in-polygon cell selection (inpolygon)
%   3. Automatic plot axis limits
%
% Available shapefiles:
%   '1777878572813_shape.shp'    — simplified study region (20 pts)
%   '1777879091712_california.shp' — actual CA state boundary (1856 pts)
%   Or any polygon shapefile covering your study area.
% ══════════════════════════════════════════════════════════════════

fname_CA_shp = 'shape.shp';   % ← CHANGE THIS LINE to swap shapefile 1777879091712_california.shp

% Fallback hardcoded polygon (study region, used if Mapping Toolbox absent)
CA_poly_lon_default = [-125.700,-118.500,-118.500,-113.600,-112.600,-112.600, ...
                       -113.100,-113.200,-114.500,-117.100,-117.400,-118.300, ...
                       -118.800,-121.300,-122.000,-124.300,-125.900,-125.900, ...
                       -125.700,-125.700];
CA_poly_lat_default = [ 43.500, 43.500, 39.700, 36.100, 34.600, 34.300, ...
                        32.700, 31.800, 31.200, 31.000, 31.100, 31.500, ...
                        32.400, 33.300, 34.000, 37.500, 40.000, 40.500, ...
                        43.000, 43.500];

% Load shapefile
% IMPORTANT: The shapefile MUST be in MATLAB's current working folder.
%   Check with: >> pwd
%   Change with: >> cd('C:/path/to/your/files')
%   Rename the file to match fname_CA_shp exactly (no spaces, exact extension).
if isfile(fname_CA_shp)
    try
        sf_CA = shaperead(fname_CA_shp);
        raw_x = sf_CA(1).X(:);
        raw_y = sf_CA(1).Y(:);

        % SELECT LARGEST POLYGON PART ONLY (mainland California)
        % The shapefile has multiple parts: part 0 = mainland, parts 1-7 = Channel Islands
        % Split by NaN separators and keep only the longest segment
        nan_idx = find(isnan(raw_x));
        nan_idx = [0; nan_idx(:); numel(raw_x)+1];
        seg_lens = diff(nan_idx) - 1;
        [~, best_seg] = max(seg_lens);
        seg_start = nan_idx(best_seg) + 1;
        seg_end   = nan_idx(best_seg+1) - 1;
        CA_poly_lon = raw_x(seg_start:seg_end)';
        CA_poly_lat = raw_y(seg_start:seg_end)';

        fprintf('>>> Loaded CA boundary: %s\n', fname_CA_shp);
        fprintf('>>> Using largest polygon part: %d vertices (mainland only)\n', numel(CA_poly_lon));
    catch ME
        fprintf('>>> ERROR loading shapefile: %s\n', ME.message);
        fprintf('>>> Check Mapping Toolbox is installed: ver(''map'')\n');
        fprintf('>>> Falling back to hardcoded polygon\n');
        CA_poly_lon = CA_poly_lon_default;
        CA_poly_lat = CA_poly_lat_default;
    end
else
    fprintf('>>> SHAPEFILE NOT FOUND: %s\n', fname_CA_shp);
    fprintf('>>> Current folder: %s\n', pwd);
    fprintf('>>> To fix: rename your shapefile to match fname_CA_shp\n');
    fprintf('>>> OR change fname_CA_shp to match your filename\n');
    fprintf('>>> Using hardcoded fallback polygon\n');
    CA_poly_lon = CA_poly_lon_default;
    CA_poly_lat = CA_poly_lat_default;
end

have_bnd = true;
% Plot and extraction limits: bounding box of polygon + small padding
CA_lon_min = min(CA_poly_lon) - 0.3;
CA_lon_max = max(CA_poly_lon) + 0.3;
CA_lat_min = min(CA_poly_lat) - 0.3;
CA_lat_max = max(CA_poly_lat) + 0.3;
fprintf('CA region: lon [%.2f, %.2f]  lat [%.2f, %.2f]\n', ...
        CA_lon_min, CA_lon_max, CA_lat_min, CA_lat_max);

%% TABLE 5 — Bird & Kagan (2004) exact from F90 lines 220-229
T5_CMT_pure_events       = [285.9,198.5,259.4,424.3,77.0,398.0,406.9,376.6,117.7,2052.8];
T5_CMT_threshold_moment  = [1.13e17,3.5e17,3.5e17,1.13e17,1.13e17,2.0e17,2.0e17,2.0e17,3.5e17,3.5e17];
T5_beta                  = [0.65,0.65,0.62,0.92,0.82,0.64,0.65,0.73,0.53,0.64];
T5_corner_magnitude      = [7.64,8.01,8.46,5.86,7.39,8.14,6.55,6.63,8.04,9.58];
T5_tGR_model_moment_rate = [1.67e12,3.8e12,1.06e13,6.7e11,1.9e11,6.7e12,9.4e11,9.0e11,4.6e12,2.85e14];
T5_assumed_mu_GPa        = [27.7,27.7,27.7,25.7,25.7,25.7,25.7,25.7,49.0,49.0];
T5_coupledThickness_km   = [3.0,8.6,18.0,0.13,0.40,13.0,1.8,1.6,3.8,18.0];
CMT_duration_s           = 25.7474*s_per_year;
T5_CMT_pure_event_rate   = T5_CMT_pure_events/CMT_duration_s;
T5_corner_moment         = Moment(T5_corner_magnitude);
T5_assumed_mu_Pa         = T5_assumed_mu_GPa*1e9;
T5_coupledThickness_m    = T5_coupledThickness_km*1e3;
% sigma values for Gaussian smoothing (Bird & Kagan 2004 Table 1, F90 lines 895-913)
T5_sigma_m = [66000,77000,93000,64000,128500,94500,88750]; % OSR CRB OCB OTF CTF CCB SUB

zone_to_T5 = [2,6,8,10]; % zone1->CTF, zone2->OTFslo, zone3->OTFfas, zone4->SUB
zone_names = {'active continent','slow ridge','fast ridge','trench'};

%% GSRM GRID (F90 lines 67-68)
GSRM_lat_max= 89.800; GSRM_lat_min=-89.800; GSRM_d_lat=0.200;
GSRM_lon_min=-179.875; GSRM_d_lon=0.250;
nRows   =1+round((GSRM_lat_max-GSRM_lat_min)/GSRM_d_lat); % 899
nColumns=round(360.0/GSRM_d_lon);                           % 1440
fprintf('Grid: %d x %d\n',nRows,nColumns);

%% 1. READ GSRM (F90 lines 350-365)
fname_strain='GSRM_average_strain_v2.1-20150901.txt';
fprintf('Reading %s...\n',fname_strain);
raw_exx=zeros(nRows,nColumns,'single');
raw_eyy=zeros(nRows,nColumns,'single');
raw_exy=zeros(nRows,nColumns,'single');
fid=fopen(fname_strain,'r'); if fid<0; error('Cannot open %s',fname_strain); end
tline=fgetl(fid);
while ischar(tline)
    s=strtrim(tline);
    if ~isempty(s)&&s(1)~='#'
        v=sscanf(tline,'%f',5);
        if numel(v)>=5
            ii=1+round((GSRM_lat_max-v(1))/GSRM_d_lat);
            jj=1+round((v(2)-GSRM_lon_min)/GSRM_d_lon);
            if ii>=1&&ii<=nRows&&jj>=1&&jj<=nColumns
                raw_exx(ii,jj)=v(3); raw_eyy(ii,jj)=v(4); raw_exy(ii,jj)=v(5);
            end
        end
    end
    tline=fgetl(fid);
end
fclose(fid);
raw_deform=(raw_exx~=0)|(raw_eyy~=0)|(raw_exy~=0);
fprintf('  Raw deforming cells: %d\n',sum(raw_deform(:)));

%% 2. CELL AREA (F90 lines 318-324)
cell_area_m2=zeros(nRows,1);
for ii=1:nRows
    top=GSRM_lat_max+0.5*GSRM_d_lat-(ii-1)*GSRM_d_lat; bot=top-GSRM_d_lat;
    cell_area_m2(ii)=R_earth_m^2*(2*pi*(1-cos((90-bot)*rpd))-2*pi*(1-cos((90-top)*rpd)))/nColumns;
end
cell_area_m2_grid=repmat(cell_area_m2,1,nColumns);
cell_area_km2_grid=cell_area_m2_grid/1e6;

%% 3. READ underwater.grd
fname_uw='underwater.grd';
fprintf('Reading %s...\n',fname_uw);
fid_uw=fopen(fname_uw,'r'); if fid_uw<0; error('Cannot open %s',fname_uw); end
uw_h1=fscanf(fid_uw,'%f',3); uw_h2=fscanf(fid_uw,'%f',3);
uw_lon_min=uw_h1(1); uw_d_lon=uw_h1(2); uw_lon_max=uw_h1(3);
uw_lat_min=uw_h2(1); uw_d_lat=uw_h2(2); uw_lat_max=uw_h2(3);
uw_nrows=round(1+(uw_lat_max-uw_lat_min)/uw_d_lat);
uw_ncols=round((uw_lon_max-uw_lon_min)/uw_d_lon)+1;
uw_raw=fscanf(fid_uw,'%d',uw_nrows*uw_ncols); fclose(fid_uw);
% underwater stored row-major: row i=1->lat_min (south), col j=1->lon_min (west)
% same as GSRM but row order is SOUTH-first (opposite of zone file)
uw_grid=reshape(uw_raw,[uw_ncols,uw_nrows])';
% uw_grid(i,j)=1 means underwater; i=1->lat=-89.8 (south)
fprintf('  %d x %d  (%.1f%% ocean)\n',uw_nrows,uw_ncols,100*mean(uw_raw));

% Build underwater mask on GSRM grid
% Both underwater.grd and GSRM use NORTH-FIRST convention (row 1 = lat_max)
% Verified: row 1 = lat=89.8 (Arctic ocean=1), same grid dimensions 899x1440
% Direct mapping: GSRM row ii -> underwater row ii (NO flip needed)
uw_GSRM=false(nRows,nColumns);
for ii=1:nRows
    ii_uw=max(1,min(uw_nrows,ii)); % direct mapping — both north-first
    for jj=1:nColumns
        lon=GSRM_lon_min+(jj-1)*GSRM_d_lon;
        jj_uw=round(1+(lon-uw_lon_min)/uw_d_lon);
        jj_uw=max(1,min(uw_ncols,jj_uw));
        uw_GSRM(ii,jj)=(uw_grid(ii_uw,jj_uw)==1);
    end
end
% New Britain exemption (F90 line 887)
for ii=1:nRows
    lat=GSRM_lat_max-(ii-1)*GSRM_d_lat;
    if lat>-10&&lat<-1
        for jj=1:nColumns
            lon=GSRM_lon_min+(jj-1)*GSRM_d_lon;
            if lon>143&&lon<156; uw_GSRM(ii,jj)=true; end
        end
    end
end

%% 4. READ PB2002 internal boundary points
fname_pb='PB2002_pts.csv';
fprintf('Reading %s...\n',fname_pb);
pb_tbl=readtable(fname_pb);
pb_lon=pb_tbl.lon; pb_lat=pb_tbl.lat; pb_code=pb_tbl.code;
pb_elev=pb_tbl.elev_m; pb_vel=pb_tbl.vel_mmpa;
pb_azim=pb_tbl.azim_seaward;
nPB=numel(pb_lon);
fprintf('  %d internal points\n',nPB);

% Convert PB2002 points to unit vectors
pb_uvec=zeros(nPB,3);
for k=1:nPB
    la=pb_lat(k)*rpd; lo=pb_lon(k)*rpd;
    pb_uvec(k,:)=[cos(la)*cos(lo),cos(la)*sin(lo),sin(la)];
end

%% 5. FIND NEAREST PB2002 BOUNDARY FOR EACH GSRM CELL (F90 lines 803-830)
fprintf('Finding nearest plate boundary for each GSRM cell...\n');
near_code =zeros(nRows,nColumns,'int8');
near_elev =zeros(nRows,nColumns,'single');
near_dist_m=ones(nRows,nColumns,'single')*1e9;
near_azim =zeros(nRows,nColumns,'int16');
raw_SUB   =false(nRows,nColumns); % for model c
test_r2_SUB=(200000/R_earth_m)^2;

for ii=1:nRows
    lat=(GSRM_lat_max-(ii-1)*GSRM_d_lat)*rpd;
    for jj=1:nColumns
        if ~raw_deform(ii,jj); continue; end
        lon=(GSRM_lon_min+(jj-1)*GSRM_d_lon)*rpd;
        u1=[cos(lat)*cos(lon),cos(lat)*sin(lon),sin(lat)];
        du=pb_uvec-u1; d2=sum(du.^2,2);
        [min_d2,k]=min(d2);
        near_code(ii,jj) =pb_code(k);
        near_elev(ii,jj) =pb_elev(k);
        near_dist_m(ii,jj)=sqrt(min_d2)*R_earth_m;
        near_azim(ii,jj) =pb_azim(k);
        raw_SUB(ii,jj)   =(pb_code(k)==7)&&(min_d2<test_r2_SUB);
    end
    if mod(ii,100)==0; fprintf('  Row %d/%d\n',ii,nRows); end
end

%% 6. MODEL b — ISOTROPIC GAUSSIAN SMOOTHING (F90 lines 836-988)
%  Redistributes offshore non-SUB strain via Gaussian kernel
fprintf('\nModel b: Isotropic Gaussian smoothing...\n');
smth_exx=zeros(nRows,nColumns,'single');
smth_eyy=zeros(nRows,nColumns,'single');
smth_exy=zeros(nRows,nColumns,'single');
test_dist_m=186000; % max distance from boundary (F90 line 839)

n_smoothed=0;
for ii=1:nRows
    lat1=(GSRM_lat_max-(ii-1)*GSRM_d_lat);
    lat1_r=lat1*rpd;
    lon1_base=GSRM_lon_min;
    for jj=1:nColumns
        if ~raw_deform(ii,jj); continue; end
        nc=near_code(ii,jj); ne=near_elev(ii,jj);
        nd=near_dist_m(ii,jj);
        lon1=lon1_base+(jj-1)*GSRM_d_lon;

        % 5 conditions (F90 lines 851-880)
        t1=(ne<0); % nearest boundary is underwater
        % Baja kludge
        if lat1>22.5&&lat1<32.7&&lon1>-120&&lon1<-110&&lat1<(34-lon1-(-120)); t1=true; end
        % South Africa kludge
        if lat1>-35&&lat1<-25.9&&lon1>35&&lon1<38; t1=true; end

        t2=(nc~=7); % not SUB
        % PA\SC kludge
        if lat1>-63&&lat1<-52.1&&lon1>-79&&lon1<-56; t2=true; end
        % SS\SB kludge
        if lat1>-9.5&&lat1<-5.5&&lon1>148.5&&lon1<154.5; t2=true; end

        t3=(nd<=test_dist_m);
        % Same kludges for t3
        if lat1>22.5&&lat1<32.7&&lon1>-120&&lon1<-110&&lat1<(34-lon1-(-120)); t3=true; end
        if lat1>-35&&lat1<-25.9&&lon1>35&&lon1<38; t3=true; end

        % t4: adjacent to intraplate cell
        iN=max(1,ii-1); iS=min(nRows,ii+1);
        jW=jj-1; if jW<1; jW=nColumns; end
        jE=jj+1; if jE>nColumns; jE=1; end
        t4=~raw_deform(iN,jj)||~raw_deform(iS,jj)||~raw_deform(ii,jW)||~raw_deform(ii,jE);

        t5=uw_GSRM(ii,jj); % donor is underwater

        smooth=t1&&t2&&t3&&t4&&t5;

        if smooth
            raw_SUB(ii,jj)=false; % no longer raw SUB (F90 line 900)
            sig_m=T5_sigma_m(nc);
            three_sig=3*sig_m;
            dRow=ceil(three_sig/(GSRM_d_lat*rpd*R_earth_m));
            dCol=ceil(three_sig/(GSRM_d_lon*cos(lat1_r)*rpd*R_earth_m));
            lon1_r=lon1*rpd;
            u1=[cos(lat1_r)*cos(lon1_r),cos(lat1_r)*sin(lon1_r),sin(lat1_r)];
            for dii=-dRow:dRow
                iT=ii+dii;
                if iT<1||iT>nRows; continue; end
                lat2=(GSRM_lat_max-(iT-1)*GSRM_d_lat)*rpd;
                for djj=-dCol:dCol
                    jT=jj+djj;
                    if jT<1; jT=jT+nColumns; end
                    if jT>nColumns; jT=jT-nColumns; end
                    lon2=(GSRM_lon_min+(jT-1)*GSRM_d_lon)*rpd;
                    u2=[cos(lat2)*cos(lon2),cos(lat2)*sin(lon2),sin(lat2)];
                    du=u1-u2; dist_m=sqrt(sum(du.^2))*R_earth_m;
                    if dist_m>three_sig; continue; end
                    coeff=(cell_area_m2(ii)/(2*pi*sig_m^2))*exp(-0.5*(dist_m/sig_m)^2);
                    % receiver must be underwater
                    recv_uw=uw_GSRM(iT,jT);
                    % New Britain exemption for receiver too
                    lat_iT=GSRM_lat_max-(iT-1)*GSRM_d_lat;
                    lon_jT=GSRM_lon_min+(jT-1)*GSRM_d_lon;
                    if lon1>143&&lon1<156&&lat1>-10&&lat1<-1; recv_uw=true; end
                    if recv_uw
                        smth_exx(iT,jT)=smth_exx(iT,jT)+coeff*raw_exx(ii,jj);
                        smth_eyy(iT,jT)=smth_eyy(iT,jT)+coeff*raw_eyy(ii,jj);
                        smth_exy(iT,jT)=smth_exy(iT,jT)+coeff*raw_exy(ii,jj);
                    else % return to donor
                        smth_exx(ii,jj)=smth_exx(ii,jj)+coeff*raw_exx(ii,jj);
                        smth_eyy(ii,jj)=smth_eyy(ii,jj)+coeff*raw_eyy(ii,jj);
                        smth_exy(ii,jj)=smth_exy(ii,jj)+coeff*raw_exy(ii,jj);
                    end
                end
            end
            n_smoothed=n_smoothed+1;
        else % no smoothing, copy as-is
            smth_exx(ii,jj)=smth_exx(ii,jj)+raw_exx(ii,jj);
            smth_eyy(ii,jj)=smth_eyy(ii,jj)+raw_eyy(ii,jj);
            smth_exy(ii,jj)=smth_exy(ii,jj)+raw_exy(ii,jj);
        end
    end
    if mod(ii,100)==0; fprintf('  Row %d/%d\n',ii,nRows); end
end
fprintf('  Smoothed %d cells\n',n_smoothed);
deform_mask=(smth_exx~=0)|(smth_eyy~=0)|(smth_exy~=0);
fprintf('  Deforming cells after model b: %d\n',sum(deform_mask(:)));

%% 7. MODEL c — STOCHASTIC SANDBLASTING TOWARD OUTER RISE (F90 lines 990-1140)
%  Moves strain quanta from convex SUB peaks seaward (440 iterations)
fprintf('\nModel c: Outer-rise sandblasting (440 iterations)...\n');
rng(1,'twister'); % reproducible random numbers
for iteration=1:440
    for ii=2:nRows-1
        lat=(GSRM_lat_max-(ii-1)*GSRM_d_lat);
        for jj=1:nColumns
            if ~raw_SUB(ii,jj)||~uw_GSRM(ii,jj); continue; end
            % Random travel distance: 66 km * N(1, 0.6) (F90 lines 1006-1012)
            travel_m=max(0, 66000*(1+0.6*randn()));
            nAzim=double(near_azim(ii,jj));
            az_r=nAzim*rpd;
            NS_frac=abs(cos(az_r)); EW_frac=abs(sin(az_r));
            denom=NS_frac+EW_frac; if denom<1e-10; continue; end
            NS_frac=NS_frac/denom; % normalized
            NS_this=(rand()<NS_frac);
            this_sup=max(abs([smth_exx(ii,jj),smth_eyy(ii,jj),smth_exy(ii,jj)]));
            if NS_this
                jW=jj-1; if jW<1; jW=nColumns; end
                jE=jj+1; if jE>nColumns; jE=1; end
                N_sup=max(abs([smth_exx(ii-1,jj),smth_eyy(ii-1,jj),smth_exy(ii-1,jj)]));
                S_sup=max(abs([smth_exx(ii+1,jj),smth_eyy(ii+1,jj),smth_exy(ii+1,jj)]));
                if this_sup>=1.001*(N_sup+S_sup)/2
                    bins=round(travel_m/(GSRM_d_lat*rpd*R_earth_m));
                    if bins~=0
                        if cos(az_r)>0; iT=ii-bins; else; iT=ii+bins; end
                        if iT>=1&&iT<=nRows
                            tester=rand();
                            if tester<0.1; jT=jj-1; if jT<1; jT=nColumns; end
                            elseif tester>0.9; jT=jj+1; if jT>nColumns; jT=1; end
                            else; jT=jj; end
                            if uw_GSRM(iT,jT)
                                smth_exx(iT,jT)=smth_exx(iT,jT)+0.001*smth_exx(ii,jj);
                                smth_eyy(iT,jT)=smth_eyy(iT,jT)+0.001*smth_eyy(ii,jj);
                                smth_exy(iT,jT)=smth_exy(iT,jT)+0.001*smth_exy(ii,jj);
                                smth_exx(ii,jj)=0.999*smth_exx(ii,jj);
                                smth_eyy(ii,jj)=0.999*smth_eyy(ii,jj);
                                smth_exy(ii,jj)=0.999*smth_exy(ii,jj);
                            end
                        end
                    end
                end
            else % EW
                jW=jj-1; if jW<1; jW=nColumns; end
                jE=jj+1; if jE>nColumns; jE=1; end
                W_sup=max(abs([smth_exx(ii,jW),smth_eyy(ii,jW),smth_exy(ii,jW)]));
                E_sup=max(abs([smth_exx(ii,jE),smth_eyy(ii,jE),smth_exy(ii,jE)]));
                if this_sup>=1.001*(W_sup+E_sup)/2
                    bins=round(travel_m/(GSRM_d_lon*cos(lat*rpd)*rpd*R_earth_m));
                    if bins~=0
                        if sin(az_r)>0; jT=jj+bins; if jT>nColumns; jT=jT-nColumns; end
                        else; jT=jj-bins; if jT<1; jT=jT+nColumns; end; end
                        tester=rand();
                        if tester<0.1; iT=min(nRows,ii+1);
                        elseif tester>0.9; iT=max(1,ii-1);
                        else; iT=ii; end
                        if uw_GSRM(iT,jT)
                            smth_exx(iT,jT)=smth_exx(iT,jT)+0.001*smth_exx(ii,jj);
                            smth_eyy(iT,jT)=smth_eyy(iT,jT)+0.001*smth_eyy(ii,jj);
                            smth_exy(iT,jT)=smth_exy(iT,jT)+0.001*smth_exy(ii,jj);
                            smth_exx(ii,jj)=0.999*smth_exx(ii,jj);
                            smth_eyy(ii,jj)=0.999*smth_eyy(ii,jj);
                            smth_exy(ii,jj)=0.999*smth_exy(ii,jj);
                        end
                    end
                end
            end
        end
    end
    if mod(iteration,50)==0; fprintf('  Iteration %d/440\n',iteration); end
end
deform_mask=(smth_exx~=0)|(smth_eyy~=0)|(smth_exy~=0);
fprintf('  Deforming cells after model c: %d\n',sum(deform_mask(:)));

%% 8. EIGENSYSTEM ON SMOOTHED STRAIN (F90 lines 1650-1657)
exx_SI=double(smth_exx)*1e-9/s_per_year;
eyy_SI=double(smth_eyy)*1e-9/s_per_year;
exy_SI=double(smth_exy)*1e-9/s_per_year;
cnr=(exx_SI+eyy_SI)/2; rad=sqrt((exx_SI-cnr).^2+exy_SI.^2);
e1h_grid=cnr-rad; e2h_grid=cnr+rad; err_grid=-(exx_SI+eyy_SI);

%% 9. ZONE FILE (F90 lines 1298-1313)
fname_zones='PB2002_tectonic_zones.grd';
fprintf('\nReading %s...\n',fname_zones);
fid_z=fopen(fname_zones,'r'); if fid_z<0; error('Cannot open %s',fname_zones); end
h1=fscanf(fid_z,'%f',3); h2=fscanf(fid_z,'%f',3);
TZ_lon_min=h1(1); TZ_d_lon=h1(2); TZ_lon_max=h1(3);
TZ_lat_min=h2(1); TZ_d_lat=h2(2); TZ_lat_max=h2(3);
nTZ_rows=round(1+(TZ_lat_max-TZ_lat_min)/TZ_d_lat);
nTZ_cols=round(1+(TZ_lon_max-TZ_lon_min)/TZ_d_lon);
zone_raw=fscanf(fid_z,'%d',nTZ_rows*nTZ_cols); fclose(fid_z);
tectonic_zones_I1=int8(reshape(zone_raw,[nTZ_cols,nTZ_rows])');

%% 10. TRANSFER ZONES TO SMOOTHED GSRM GRID (F90 lines 1322-1332)
fprintf('Transferring zones...\n');
smoothed_zone=zeros(nRows,nColumns,'int8');
for ii=1:nRows
    lat=GSRM_lat_max-(ii-1)*GSRM_d_lat;
    iT=max(1,min(nTZ_rows,round(1+(TZ_lat_max-lat)/TZ_d_lat)));
    for jj=1:nColumns
        lon=GSRM_lon_min+(jj-1)*GSRM_d_lon;
        gL=lon; if gL<TZ_lon_min; gL=gL+360; end
        jT=max(1,min(nTZ_cols,round(1+(gL-TZ_lon_min)/TZ_d_lon)));
        smoothed_zone(ii,jj)=tectonic_zones_I1(iT,jT);
    end
end

%% 11. NN EXPANSION (F90 lines 1342-1410)
fprintf('NN expansion...\n');
for iteration=1:1000
    snap=smoothed_zone; nProb=0; nNew=0;
    for ii=1:nRows
        for jj=1:nColumns
            if snap(ii,jj)~=0||~deform_mask(ii,jj); continue; end
            nProb=nProb+1;
            niz=zeros(1,4,'int32'); bsup=zeros(1,4,'int32');
            nbr=[ii-1,jj;ii+1,jj;ii,jj-1;ii,jj+1];
            if nbr(3,2)<1; nbr(3,2)=nbr(3,2)+nColumns; end
            if nbr(4,2)>nColumns; nbr(4,2)=nbr(4,2)-nColumns; end
            for nb=1:4
                ni=nbr(nb,1); nj=nbr(nb,2);
                if ni<1||ni>nRows; continue; end
                it=snap(ni,nj); if it<=0; continue; end
                niz(it)=niz(it)+1;
                sv=0;
                if ni>1&&snap(ni-1,nj)>0; sv=sv+1; end
                if ni<nRows&&snap(ni+1,nj)>0; sv=sv+1; end
                jW=nj-1; if jW<1; jW=nColumns; end
                jE=nj+1; if jE>nColumns; jE=1; end
                if snap(ni,jW)>0; sv=sv+1; end
                if snap(ni,jE)>0; sv=sv+1; end
                bsup(it)=max(bsup(it),int32(sv));
            end
            done=false;
            for nc=4:-1:1
                if done; break; end
                for sv=8:-1:0
                    if done; break; end
                    tz=0; for k=4:-1:1; if bsup(k)==sv; tz=k; break; end; end
                    if tz>0&&niz(tz)==nc
                        smoothed_zone(ii,jj)=tz; nNew=nNew+1; done=true;
                    end
                end
            end
        end
    end
    fprintf('  Iter %3d: %6d problems, %6d assigned\n',iteration,nProb,nNew);
    if nProb==0||nNew==0; break; end
end

%% 12. WNA PATCHES (F90 lines 1416-1434)
for ii=1:nRows
    lat=GSRM_lat_max-(ii-1)*GSRM_d_lat;
    for jj=1:nColumns
        if smoothed_zone(ii,jj)==0; continue; end
        lon=GSRM_lon_min+(jj-1)*GSRM_d_lon;
        if lat>28&&lat<40&&lon>-131&&lon<-115;                       smoothed_zone(ii,jj)=1; end
        if lat>=40&&lat<=46&&lon>-126&&lon<-121;                     smoothed_zone(ii,jj)=4; end
        if lat>=40&&lat<=50&&lon>-121&&lon<-115;                     smoothed_zone(ii,jj)=1; end
        if lat>=44&&lat<=54&&lon>(-122-1.5*(lat-50))&&lon<-115;      smoothed_zone(ii,jj)=1; end
    end
end

%% 13. ZERO-STRAIN RESET (F90 lines 1439-1443)
smoothed_zone(smoothed_zone~=0&~deform_mask)=0;

fprintf('\nFinal zone distribution:\n');
nd=sum(deform_mask(:));
for z=1:4
    fprintf('  Zone %d (%s): %d (%.1f%%)\n',z,zone_names{z},sum(smoothed_zone(:)==z),100*sum(smoothed_zone(:)==z)/nd);
end

%% 14. READ CATALOG
fname_cat='GCMT_clean.csv';
cat_Mc=5.767; cat_M0=Moment(cat_Mc); catalog_years=28.0;
fprintf('\nReading %s...\n',fname_cat);
ct=readtable(fname_cat);
yr_eq=ct.year; lon_eq=ct.lon; lat_eq=ct.lat; depth_eq=ct.depth; mag_eq=ct.mag;
cal_mask=depth_eq<=70&mag_eq>=cat_Mc&yr_eq>=1977&yr_eq<=2004;
test_mask=depth_eq<=70&mag_eq>=cat_Mc&yr_eq>=2005&yr_eq<=2012;
lon_cal=lon_eq(cal_mask); lat_cal=lat_eq(cal_mask);
lon_test=lon_eq(test_mask); lat_test=lat_eq(test_mask);
N_cal=sum(cal_mask); N_test=sum(test_mask);
fprintf('  Cal:%d  Test:%d\n',N_cal,N_test);

%% 15. AREAS AND CALIBRATION COUNTS
plate_area_zone=zeros(4,1); intraplate_area=0;
for ii=1:nRows
    for jj=1:nColumns
        iz=smoothed_zone(ii,jj);
        if deform_mask(ii,jj)&&iz>0; plate_area_zone(iz)=plate_area_zone(iz)+cell_area_m2(ii);
        elseif ~deform_mask(ii,jj); intraplate_area=intraplate_area+cell_area_m2(ii); end
    end
end
boundary_cal_count=zeros(4,1); intraplate_cal_count=0;
for k=1:N_cal
    ii_eq=max(1,min(nRows,1+round((GSRM_lat_max-lat_cal(k))/GSRM_d_lat)));
    jj_eq=max(1,min(nColumns,1+round((lon_cal(k)-GSRM_lon_min)/GSRM_d_lon)));
    if deform_mask(ii_eq,jj_eq)
        iz=smoothed_zone(ii_eq,jj_eq); if iz>0; boundary_cal_count(iz)=boundary_cal_count(iz)+1; end
    else; intraplate_cal_count=intraplate_cal_count+1; end
end
intraplate_SI=intraplate_cal_count/(intraplate_area*catalog_years*s_per_year);
fprintf('  Intraplate: %d events, SI=%.4e\n',intraplate_cal_count,intraplate_SI);

%% 16. PASS 1 — TENTATIVE SEISMICITY
fprintf('Pass 1...\n');
tentative_per_s=zeros(4,1);
for ii=1:nRows
    for jj=1:nColumns
        iz=smoothed_zone(ii,jj); if iz==0; continue; end
        T5c=zone_to_T5(iz);
        e1r=min([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
        e3r=max([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
        e2r=-e1r-e3r;
        if e2r<0; Mm3=T5_assumed_mu_Pa(T5c)*2*e3r;
        else; Mm3=T5_assumed_mu_Pa(T5c)*2*(-e1r); end
        Mm2=Mm3*T5_coupledThickness_m(T5c);
        sCMT=T5_CMT_pure_event_rate(T5c)*Mm2/T5_tGR_model_moment_rate(T5c);
        Md=cat_M0; McT=T5_CMT_threshold_moment(T5c); Mcor=T5_corner_moment(T5c);
        arg=(McT-Md)/Mcor; if arg<-100; G=0; else; G=(Md/McT)^(-T5_beta(T5c))*exp(arg); end
        tentative_per_s(iz)=tentative_per_s(iz)+G*sCMT*cell_area_m2(ii);
    end
end
tentative_per_cat=tentative_per_s*catalog_years*s_per_year;
BSF=zeros(4,1);
fprintf('  Zone calibration:\n');
fprintf('  %-4s %-10s %-12s %-12s %-10s %-10s\n','Zone','Obs','Intra_floor','Tentative','BSF','Paper_f');
paper_BSF=[0.86,1.00,1.00,2.90];
for z=1:4
    intra_fl=plate_area_zone(z)*intraplate_SI*catalog_years*s_per_year;
    BSF(z)=(boundary_cal_count(z)-intra_fl)/tentative_per_cat(z);
    fprintf('  %-4d %-10d %-12.2f %-12.4f %-10.5f %-10.2f\n',...
            z,boundary_cal_count(z),intra_fl,tentative_per_cat(z),BSF(z),paper_BSF(z));
end

%% 17. PASS 2 — FINAL RATES
forecast_Mc=cat_Mc; forecast_M0=Moment(forecast_Mc);
intra_fac=(forecast_M0/cat_M0)^(-0.63)*exp((cat_M0-forecast_M0)/Moment(9.0));
intraplate_SI_fc=intraplate_SI*intra_fac;
fprintf('Pass 2...\n');
epi_rate_m2s=zeros(nRows,nColumns);
for ii=1:nRows
    for jj=1:nColumns
        iz=smoothed_zone(ii,jj);
        epi_rate_m2s(ii,jj)=intraplate_SI_fc;
        if iz==0; continue; end
        T5c=zone_to_T5(iz);
        e1r=min([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
        e3r=max([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
        e2r=-e1r-e3r;
        if e2r<0; Mm3=T5_assumed_mu_Pa(T5c)*2*e3r;
        else; Mm3=T5_assumed_mu_Pa(T5c)*2*(-e1r); end
        Mm2=Mm3*T5_coupledThickness_m(T5c);
        sCMT=T5_CMT_pure_event_rate(T5c)*Mm2/T5_tGR_model_moment_rate(T5c);
        Md=forecast_M0; McT=T5_CMT_threshold_moment(T5c); Mcor=T5_corner_moment(T5c);
        arg=(McT-Md)/Mcor; if arg<-100; G=0; else; G=(Md/McT)^(-T5_beta(T5c))*exp(arg); end
        epi_rate_m2s(ii,jj)=BSF(iz)*G*sCMT+intraplate_SI_fc;
    end
end
active_g=epi_rate_m2s>0;
total_rate=sum(epi_rate_m2s(active_g).*cell_area_m2_grid(active_g))*s_per_year;
log10_epi=nan(nRows,nColumns); log10_epi(active_g)=log10(epi_rate_m2s(active_g));
fprintf('Global rate m>=%.3f: %.2f ev/yr  (expected ~164)\n',forecast_Mc,total_rate);
fprintf('log10_epi median  : %.4f  (paper: [-21.7,-16.8])\n',median(log10_epi(active_g)));

%% 18. VALIDATION
fprintf('\n%s\n',repmat('=',1,60));
fprintf('VALIDATION (2005-2012)\n'); fprintf('%s\n',repmat('=',1,60));
fprintf('N-test: forecast=%.1f  obs=%d  ratio=%.3f\n',total_rate*8,N_test,total_rate*8/N_test);
ci_t=zeros(N_test,1); cj_t=zeros(N_test,1);
for k=1:N_test
    ci_t(k)=max(1,min(nRows,1+round((GSRM_lat_max-lat_test(k))/GSRM_d_lat)));
    cj_t(k)=max(1,min(nColumns,1+round((lon_test(k)-GSRM_lon_min)/GSRM_d_lon)));
end
mean_dens=sum(epi_rate_m2s(:).*cell_area_m2_grid(:))/sum(cell_area_m2_grid(:));
wt=epi_rate_m2s(active_g).*cell_area_m2_grid(active_g)*s_per_year/total_rate;
I0=sum(wt.*log2(epi_rate_m2s(active_g)/mean_dens));
lg=zeros(N_test,1);
for k=1:N_test
    d=epi_rate_m2s(ci_t(k),cj_t(k));
    if d>0; lg(k)=log2(d/mean_dens); else; lg(k)=-Inf; end
end
I1=mean(lg(isfinite(lg)));
[~,si]=sort(epi_rate_m2s(:),'descend');
cum_a=cumsum(cell_area_m2_grid(si))/sum(cell_area_m2_grid(:));
eic=zeros(nRows*nColumns,1);
for k=1:N_test; lin=sub2ind([nRows,nColumns],ci_t(k),cj_t(k)); eic(lin)=eic(lin)+1; end
cum_eq=cumsum(eic(si))/N_test; ASS=(trapz(cum_a,cum_eq)-0.5)/0.5;
fprintf('I0=%.3f (paper d:3.833 f:4.042)\n',I0);
fprintf('I1=%.3f (paper d:3.47  f:3.68)\n',I1);
fprintf('ASS=%.4f (paper d:0.961 f:0.965)\n',ASS);
if sum(~isfinite(lg))>0; fprintf('(%d test events in zero-rate cells)\n',sum(~isfinite(lg))); end

%% 19. CALIFORNIA (Mc=3.6)
lat_vec=GSRM_lat_max-(0:nRows-1)'*GSRM_d_lat;
lon_vec=GSRM_lon_min+(0:nColumns-1)*GSRM_d_lon;
[lon_grid,lat_grid]=meshgrid(lon_vec,lat_vec);
% Use inpolygon for accurate cell selection inside study region
% First apply bounding box for speed, then inpolygon for accuracy
bbox_mask = (lon_grid>=CA_lon_min)&(lon_grid<=CA_lon_max)& ...
            (lat_grid>=CA_lat_min)&(lat_grid<=CA_lat_max)&deform_mask;
[in_poly] = inpolygon(lon_grid(bbox_mask), lat_grid(bbox_mask), ...
                      CA_poly_lon, CA_poly_lat);
CA_mask = false(nRows,nColumns);
bbox_idx = find(bbox_mask);
CA_mask(bbox_idx(in_poly)) = true;
fprintf('  CA cells in polygon: %d (bbox had %d)\n', sum(CA_mask(:)), sum(bbox_mask(:)));
Mc_CA=3.6; M0_CA=Moment(Mc_CA);
intra_CA=intraplate_SI*(M0_CA/cat_M0)^(-0.63)*exp((cat_M0-M0_CA)/Moment(9.0));
lambda_Mc_CA=zeros(nRows,nColumns);
CA_idx=find(CA_mask);
for idx=1:numel(CA_idx)
    [ii,jj]=ind2sub([nRows,nColumns],CA_idx(idx));
    iz=smoothed_zone(ii,jj); if iz==0; continue; end
    T5c=zone_to_T5(iz);
    e1r=min([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
    e3r=max([e1h_grid(ii,jj),e2h_grid(ii,jj),err_grid(ii,jj)]);
    e2r=-e1r-e3r;
    if e2r<0; Mm3=T5_assumed_mu_Pa(T5c)*2*e3r;
    else; Mm3=T5_assumed_mu_Pa(T5c)*2*(-e1r); end
    Mm2=Mm3*T5_coupledThickness_m(T5c);
    sCMT=T5_CMT_pure_event_rate(T5c)*Mm2/T5_tGR_model_moment_rate(T5c);
    Md=M0_CA; McT=T5_CMT_threshold_moment(T5c); Mcor=T5_corner_moment(T5c);
    arg=(McT-Md)/Mcor; if arg<-100; G=0; else; G=(Md/McT)^(-T5_beta(T5c))*exp(arg); end
    lambda_Mc_CA(ii,jj)=(BSF(iz)*G*sCMT+intra_CA)*cell_area_m2(ii)*s_per_year;
end
lon_CA=lon_grid(CA_mask); lat_CA=lat_grid(CA_mask);
zone_CA=smoothed_zone(CA_mask); lam_CA=lambda_Mc_CA(CA_mask);
area_km2_CA=cell_area_km2_grid(CA_mask);
mu_CA=lam_CA./area_km2_CA; log10_mu_CA=log10(mu_CA);
fin_CA=isfinite(log10_mu_CA)&lam_CA>0; log10_plot=log10_mu_CA(fin_CA);
fprintf('\nCalifornia (Mc=%.1f):\n',Mc_CA);
fprintf('  Active: %d  Rate: %.2f ev/yr  Median: %.4f log10(ev/yr/km2)\n',...
        sum(fin_CA),sum(lam_CA(fin_CA)),median(log10_plot));
for z=1:4; fprintf('  Zone %d (%s): %d cells  %.2f ev/yr\n',...
    z,zone_names{z},sum(zone_CA(fin_CA)==z),sum(lam_CA(zone_CA==z&fin_CA))); end

%% 20. SAVE — Three separate output files
spatial_PDF_CA = lam_CA / sum(lam_CA);

% ── File 1: Full California results (all columns) ─────────────────
writetable(table(lon_CA, lat_CA, area_km2_CA, int32(zone_CA), ...
                 lam_CA, mu_CA, log10_mu_CA, spatial_PDF_CA, ...
    'VariableNames', {'Longitude','Latitude','Area_km2','Zone', ...
                      'Rate_above_Mc3p6','mu_per_yr_per_km2','log10_mu','Spatial_PDF'}), ...
    'SHIFT_GSRM2_California_Mc3p6.csv');

% ── File 2: Background rate (reference only, not needed for ETAS) ─
% Contains: lon, lat, background rate (events/yr/km2), log10 of rate
% NOTE: For ETAS synthetic catalogs use File 3 (Spatial PDF) only.
%       This file is for verification/plotting purposes.
writetable(table(lon_CA, lat_CA, area_km2_CA, int32(zone_CA), ...
                 mu_CA, log10_mu_CA, lam_CA, ...
    'VariableNames', {'Longitude','Latitude','Area_km2','Zone', ...
                      'Background_rate_per_yr_per_km2', ...
                      'log10_Background_rate', ...
                      'Total_rate_per_cell_per_yr'}), ...
    'CA_Background_Rate.csv');

% ── File 3: Spatial PDF only ──────────────────────────────────────
% Contains: lon, lat, spatial PDF value (sums to 1.0)
% Use this for: ETAS model input mu(x,y), spatial probability map
% NOTE: This is the SHAPE of seismicity only — absolute rate is
%       underpredicted by SHIFT for California (factor ~4-5).
%       Multiply by your ETAS-fitted background rate to get mu(x,y).
writetable(table(lon_CA, lat_CA, spatial_PDF_CA, ...
    'VariableNames', {'Longitude','Latitude','Spatial_PDF'}), ...
    'CA_Spatial_PDF_ETAS.csv');

fprintf('Saved 3 output files:\n');
fprintf('  SHIFT_GSRM2_California_Mc3p6.csv  — full results (all columns)\n');
fprintf('  CA_Background_Rate.csv             — background rate, reference only\n');
fprintf('  CA_Spatial_PDF_ETAS.csv            — ETAS input: spatial PDF (sums to %.8f)\n', ...
        sum(spatial_PDF_CA));
fprintf('\nFor ETAS synthetic catalogs: use CA_Spatial_PDF_ETAS.csv\n');
fprintf('  mu(x,y) = Spatial_PDF(x,y) * mu_total  where mu_total from ETAS fit\n');

%% 21. PLOTS
zcmap=[0.85 0.25 0.25;0.25 0.50 0.90;0.25 0.80 0.35;0.90 0.55 0.10];
fin_g2d=isfinite(log10_epi);


figure(1);clf;scatter(lon_grid(fin_g2d),lat_grid(fin_g2d),2,log10_epi(fin_g2d),'filled','MarkerFaceAlpha',0.5);
colormap(gca,'jet');cb=colorbar;cb.Label.String='log_{10}(epicentroids/m^2/s)';caxis([-22 -17]);
title('SHIFT-GSRM2d Global m\geq5.767 (with b+c smoothing)','FontSize',12,'FontWeight','bold');
xlabel('Longitude');ylabel('Latitude');xlim([-180 180]);ylim([-90 90]);grid on;box on;

figure(2);clf;hold on;
for z=1:4
    zm=(smoothed_zone==z)&deform_mask;
    if any(zm(:)); scatter(lon_grid(zm),lat_grid(zm),2,zcmap(z,:),'filled',...
            'MarkerFaceAlpha',0.5,'DisplayName',sprintf('Zone %d: %s',z,zone_names{z})); end
end
legend('Location','southoutside','NumColumns',4);
title('Tectonic Zones (GRD+NN+WNA patches)','FontSize',12,'FontWeight','bold');
xlabel('Longitude');ylabel('Latitude');xlim([-180 180]);ylim([-90 90]);grid on;box on;

figure(3);clf;scatter(lon_CA(fin_CA),lat_CA(fin_CA),50,log10_plot,'filled','MarkerFaceAlpha',0.9);
if have_bnd;hold on;plot(CA_poly_lon,CA_poly_lat,'k-','LineWidth',2,'Color',[0.1 0.1 0.1]);end
colormap(gca,'jet');cb=colorbar;cb.Label.String='log_{10}(\mu) [events/yr/km^2]';
title(sprintf('California Background Rate (Mc=%.1f)',Mc_CA),'FontSize',12,'FontWeight','bold');
xlabel('Longitude');ylabel('Latitude');xlim([CA_lon_min CA_lon_max]);ylim([CA_lat_min CA_lat_max]);axis equal;grid on;box on;

figure(4);clf;hold on;
for z=1:4
    m=zone_CA==z&fin_CA;
    if any(m); scatter(lon_CA(m),lat_CA(m),30,zcmap(z,:),'filled','MarkerFaceAlpha',0.85,...
            'DisplayName',sprintf('Zone %d: %s',z,zone_names{z})); end
end
if have_bnd;plot(CA_poly_lon,CA_poly_lat,'k-','LineWidth',2,'Color',[0.1 0.1 0.1],'HandleVisibility','off');end
legend('Location','northwest');title('Zones — California','FontSize',12,'FontWeight','bold');
xlabel('Longitude');ylabel('Latitude');xlim([CA_lon_min CA_lon_max]);ylim([CA_lat_min CA_lat_max]);axis equal;grid on;box on;

figure(5);clf;histogram(log10_plot,40,'FaceColor',[0.2 0.4 0.7],'EdgeColor','white','FaceAlpha',0.85);
hold on;if isfinite(median(log10_plot));xline(median(log10_plot),'r--','LineWidth',2,'Label',sprintf('Med=%.3f',median(log10_plot)),'FontSize',9);end
xlabel('log_{10}(\mu) [ev/yr/km^2]');ylabel('Count');title(sprintf('CA Rate Dist. Mc=%.1f',Mc_CA),'FontSize',12,'FontWeight','bold');grid on;box on;

figure(6);clf;scatter(lon_CA(fin_CA),lat_CA(fin_CA),50,log10(spatial_PDF_CA(fin_CA)),'filled','MarkerFaceAlpha',0.9);
if have_bnd;hold on;plot(CA_poly_lon,CA_poly_lat,'k-','LineWidth',2,'Color',[0.1 0.1 0.1]);end
colormap(gca,'hot');cb=colorbar;cb.Label.String='log_{10}(Spatial PDF)';
title('Spatial PDF — ETAS Input','FontSize',12,'FontWeight','bold');
xlabel('Longitude');ylabel('Latitude');xlim([CA_lon_min CA_lon_max]);ylim([CA_lat_min CA_lat_max]);axis equal;grid on;box on;

figure(7);clf;plot(cum_a,1-cum_eq,'b-','LineWidth',2);hold on;plot([0 1],[1 0],'k--','LineWidth',1.5);
xlabel('Fraction of domain');ylabel('Fraction failures');
title(sprintf('Molchan Diagram — ASS=%.4f',ASS),'FontSize',12,'FontWeight','bold');
legend({'SHIFT-GSRM2d','Random'},'Location','northeast');grid on;box on;

%% 22. SUMMARY
fprintf('\n%s\n',repmat('=',1,60));
fprintf('FINAL SUMMARY — SHIFT-GSRM2 model d (with b+c smoothing)\n');
fprintf('%s\n',repmat('=',1,60));
fprintf('BSF (calibrated)   : [%.5f %.5f %.5f %.5f]\n',BSF);
fprintf('BSF (paper model f): [0.86  1.00  1.00  2.90]\n');
fprintf('Global rate        : %.2f ev/yr  (expected ~164)\n',total_rate);
fprintf('log10 median       : %.4f  (paper: [-21.7,-16.8])\n',median(log10_epi(active_g)));
fprintf('I0=%.3f  I1=%.3f  ASS=%.4f\n',I0,I1,ASS);
fprintf('Paper model d: I0=3.833  I1=3.47  ASS=0.961\n');
fprintf('\nCalifornia (Mc=%.1f):\n',Mc_CA);
fprintf('  Active cells: %d  Rate: %.2f ev/yr\n',sum(fin_CA),sum(lam_CA(fin_CA)));
fprintf('  log10_mu med: %.4f\n',median(log10_plot));
fprintf('  PDF sum     : %.8f\n',sum(spatial_PDF_CA));
fprintf('\nZone breakdown:\n');
for z=1:4
    nz=sum(smoothed_zone(:)==z&deform_mask(:));
    rz=sum(epi_rate_m2s(smoothed_zone==z).*cell_area_m2_grid(smoothed_zone==z))*s_per_year;
    fprintf('  Zone %d (%s): %d cells  %.2f ev/yr\n',z,zone_names{z},nz,rz);
end
fprintf('%s\n',repmat('=',1,60));
