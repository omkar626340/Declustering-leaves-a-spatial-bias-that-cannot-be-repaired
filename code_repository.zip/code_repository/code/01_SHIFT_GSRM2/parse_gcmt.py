"""
parse_gcmt.py — Parse GCMT EQC catalog into clean CSV for MATLAB

Usage: python3 parse_gcmt.py

Input:  GCMT_shallow_5p767_1977-2013.eqc.txt  (in same folder)
Output: GCMT_clean.csv

EQC format: Harv. CMT YYYY.MM.DD HH:MM:SS.s lon lat depth mag ...
Some time fields have a space before single-digit seconds:
  e.g. "13:54: 9.8" splits into two tokens — handled here.
"""

import os

fname_in  = 'GCMT_shallow_5p767_1977-2013.eqc.txt'
fname_out = 'GCMT_clean.csv'

if not os.path.isfile(fname_in):
    print(f"ERROR: {fname_in} not found in current folder.")
    exit(1)

lines = open(fname_in).readlines()
yrs=[]; lons=[]; lats=[]; deps=[]; mags=[]

for line in lines:
    line = line.strip()
    if not line or line.startswith('#'):
        continue
    parts = line.split()
    if len(parts) < 8:
        continue

    # parts[2] = YYYY.MM.DD
    try:
        yr = int(parts[2].split('.')[0])
    except:
        continue

    # Find lon: first token after index 2 with no ':' that parses as float
    lon_idx = None
    for i in range(3, len(parts)):
        if ':' not in parts[i]:
            try:
                float(parts[i])
                lon_idx = i
                break
            except:
                pass

    if lon_idx is None or lon_idx + 3 >= len(parts):
        continue

    try:
        lon = float(parts[lon_idx])
        lat = float(parts[lon_idx+1])
        dep = float(parts[lon_idx+2])
        mag = float(parts[lon_idx+3])
    except:
        continue

    yrs.append(yr); lons.append(lon); lats.append(lat)
    deps.append(dep); mags.append(mag)

n = len(yrs)
cal  = sum(1 for i in range(n) if yrs[i]>=1977 and yrs[i]<=2004 and deps[i]<=70 and mags[i]>=5.767)
test = sum(1 for i in range(n) if yrs[i]>=2005 and yrs[i]<=2012 and deps[i]<=70 and mags[i]>=5.767)

print(f"Parsed:      {n} events")
print(f"Year range:  {min(yrs)}-{max(yrs)}")
print(f"Calibration (1977-2004, m>=5.767, dep<=70): {cal}  (expected ~4602)")
print(f"Test        (2005-2012, m>=5.767, dep<=70): {test} (expected ~1694)")

with open(fname_out,'w') as f:
    f.write('year,lon,lat,depth,mag\n')
    for i in range(n):
        f.write(f'{yrs[i]},{lons[i]},{lats[i]},{deps[i]},{mags[i]}\n')

print(f"Saved: {fname_out}")
