#!/usr/bin/env python3
"""
bias_metrics.py — Objective 1, Analyses 1–3.

Turns the declustering shards into every number behind Figures 3–9 and
Tables 2–4 of the progress report. Stops before the PSHA propagation.

    python bias_metrics.py --stage rate     # Analysis 1
    python bias_metrics.py --stage bvalue   # Analysis 2
    python bias_metrics.py --stage compound # Analysis 3
    python bias_metrics.py --stage all

Outputs (under OUT/metrics/):
    rate_residual_maps.npz      R[method, realisation, cell], median, IQR
    table2_rate_structure.csv   Moran's I, ρ(logμ), ρ(fault), partials, %>IQR/2
    fig4_bias_vs_rate.csv       binned bias-vs-background-rate curves
    bvalue_maps.npz             b̂[method, track, k, realisation, gridpoint]
    table3_b_structure.csv
    fig7_b_vs_logmu.csv, fig8_b_vs_fault.csv
    table4_compounding.csv
    lisa_<method>.csv           local Moran's I, 999 conditional permutations

Definitions follow §2.4–2.5 of the report. Anything the report leaves implicit
is stated explicitly here and flagged with "CHOICE:".
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, field
import os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.spatial import cKDTree

try:
    import h5py
except ImportError:  # shards are -v7.3 = HDF5
    raise SystemExit("pip install h5py")


# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------

# data folder: environment variable DATA_DIR, default ../data_archive next to the code repository
_DATA = Path(os.environ.get("DATA_DIR", Path(__file__).resolve().parents[3] / "data_archive"))


@dataclass
class Cfg:
    # Must match C.out_root in matlab/config_run.m. All Objective 1 declustering
    # output was consolidated under Objective_1_Final on 2026-08-12.
    # paths inside this repository (code/02_rate_and_b_value/ -> repository root)
    root: Path = _DATA          # outputs go to data/metrics_<tag>/
    cat_dir: Path = _DATA / "02_synthetic_catalogs" / "complete_catalogs"
    mu_csv: Path = _DATA / "01_background_rate_map" / "CA_Spatial_PDF_ETAS.csv"
    # QFaults_CA.shp -- the California-clipped Quaternary fault database, which is
    # what compute_residual_bias_v7.m (FAULT_SHP, line 56) and compute_b_bias_v8.m
    # both use. NOT SHP/Qfaults_US_Database.shp, which is the global 112k-feature
    # set spanning lon -180..180 and would make the KD-tree needlessly huge.
    fault_shp: Path = _DATA / "09_auxiliary" / "QFaults_CA.shp"

    T_years: float = 100.0
    Mc: float = 3.6
    dM: float = 0.1            # magnitudes ARE binned at generation (verified: 36 unique
                               # values, max|m-round(m,.1)| = 8.9e-16). Use the binned
                               # Tinti-Mulargia form with Mc = 3.6 and NO half-bin shift;
                               # that recovers b = 1.0019 against the true 1.000, while
                               # dM = 0 gives 1.1268 and the half-bin variant 0.8979.
    b_true: float = 1.00
    bg_total_yr: float = 24.0  # background seed: PDF x 24 events/yr (Leila/Mizrahi)
    # simulation box — must match simulate_ca_catalogs.py::_polygon()
    lon_min: float = -125.0
    lon_max: float = -113.0
    lat_min: float = 32.0
    lat_max: float = 43.0

    # The background PDF grid is 0.25 deg lon x 0.20 deg lat. The rate grid must be
    # an INTEGER MULTIPLE of that, anchored on a native cell EDGE, or PDF cells
    # straddle bin boundaries: their whole mu lands in one bin while their events,
    # which the generator jitters uniformly inside the cell, fall on both sides.
    # Measured 2026-08-25, square 0.5 deg: 117 of 150 cells off by >10% in
    # observed/expected background count, and the error correlated with log mu
    # (rho = -0.202) -- the very axis the headline result is measured on.
    # See DECISIONS.md 2026-08-25.
    rate_kx: int = 1           # native cells per analysis cell, longitude
    rate_ky: int = 1           # native cells per analysis cell, latitude
    # Per-cell estimator across realisations. "mean" is the pooled rate
    # sum(counts)/(n_real*T); "median" is what the pipeline used before 2026-08-25.
    # The median of a low-count Poisson is discretised and biased, and does NOT
    # converge with more realisations: scoring the TRUE BACKGROUND against its own
    # mu on the native grid gave R = -0.085 at 50 realisations and -0.081 at 200,
    # with a spurious rho(R, log mu) of +0.296 rising to +0.381. The mean gives
    # -0.006 -> -0.002 and rho +0.002 -> +0.034.
    rate_estimator: str = "mean"
    rate_cell: float = 0.50    # ° — LEGACY, only used to label old outputs. At 0.25 the CA
                               # polygon + mu*50>=1 criterion leaves 103 cells,
                               # at 0.50 it leaves 97, at 1.0 only 41: the binding
                               # constraint is mu, not occupancy, so coarsening
                               # past 0.5 loses resolution for nothing.
    b_cell: float = 0.50       # ° — b-value output grid
    # compute_b_bias_v8.m used K_VALS = [100 200 500], median radius 66-161 km on
    # its 33,113-event catalogues. Ours hold 5,507 (background 11/yr not 122.5/yr),
    # so the same k spans 136-259 km and thinning at that separation leaves only 17
    # points -- below the 20 Moran's I needs. k=25/50 reproduce the ORIGINAL PHYSICAL
    # RADIUS (86-146 km); the higher k are kept so Table S1 stays comparable.
    k_list: tuple = (25, 50, 100, 200, 500)
    k_primary: int = 100  # MUST match the k reported in the tables. Was 50, which
                          # silently exported fig7_fig8_b_scatter.csv (and hence
                          # Figures 7-9 and the compounding analysis) at k = 50 while
                          # every table quoted k = 100. Zaliapin's rho(b-bias, log mu)
                          # is -0.338 at k = 50 and +0.056 at k = 100: a sign flip.
    k_mc: int = 1000           # disjoint neighbourhood for the Track-2 local Mc
    maxc_offset: float = 0.2

    # VALIDITY, taken from compute_residual_bias_v7.m lines 61 + 124:
    #     MIN_EXP_COUNT = 1;
    #     valid_mask = poly_mask & (mu_50yr >= MIN_EXP_COUNT);
    # i.e. inside the California polygon AND EXPECTED background count over
    # 50 yr >= 1. The test is on the ANALYTIC mu, not on observed counts --
    # mu has no sampling error, so thresholding observed counts (the shipped
    # min_events_cell = 5) is the wrong test and left 1 of 1750 cells valid.
    min_exp_count: float = 1.0
    ca_shp: Path = _DATA / "09_auxiliary" / "california.shp"
    iqr_outlier: float = 3.0   # drop |R − med| > 3·IQR before the tests
    n_perm: int = 999
    seed: int = 20260811

    methods: tuple = ("GK74", "Uhrhammer", "Gruenthal", "Zaliapin", "Reasenberg")
    include_undeclustered: bool = True
    standard_only: bool = True   # Analyses 1–3 use the 5 standard configs;
                                 # set False to repeat them across the sweep fan

    n_cat: int = 0             # 0 = every shard; else the first N realisations
    out: Path = field(init=False)

    def __post_init__(self):
        self.out = self.root / "metrics"
        self.out.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------------
# Spatial statistics
# ----------------------------------------------------------------------------

def queen_weights(ij: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Row-standardised queen contiguity for cells on an integer lattice.

    ij : (n, 2) integer (row, col) indices. Returns (neighbour index array as
    a ragged list flattened into indptr/indices form, weights).
    """
    lookup = {tuple(v): k for k, v in enumerate(ij)}
    rows, cols, vals = [], [], []
    offs = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    for k, (r, c) in enumerate(ij):
        nb = [lookup[(r + dr, c + dc)] for dr, dc in offs if (r + dr, c + dc) in lookup]
        if not nb:
            continue
        w = 1.0 / len(nb)
        rows += [k] * len(nb)
        cols += nb
        vals += [w] * len(nb)
    # explicit dtypes: np.array([]) defaults to float64, and a float array
    # cannot index, which blows up in _sub when a lattice has no neighbours
    return (np.asarray(rows, dtype=np.intp),
            np.asarray(cols, dtype=np.intp),
            np.asarray(vals, dtype=float))


def knn_weights(xy: np.ndarray, k: int = 8) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Row-standardised k-nearest-neighbour weights, for the thinned b-grid.

    CHOICE: the thinned b-value points are no longer a lattice, so queen
    contiguity is undefined. k=8 KNN is the closest analogue to queen on a
    regular grid; report the choice alongside Moran's I.
    """
    tree = cKDTree(xy)
    _, idx = tree.query(xy, k=k + 1)
    idx = idx[:, 1:]
    n = len(xy)
    rows = np.repeat(np.arange(n), k).astype(np.intp)
    cols = idx.ravel().astype(np.intp)
    vals = np.full(n * k, 1.0 / k)
    return rows, cols, vals


def morans_i(x: np.ndarray, rows, cols, vals, n_perm: int, rng) -> dict:
    """Global Moran's I with permutation inference."""
    x = np.asarray(x, float)
    ok = np.isfinite(x)
    if ok.sum() < 20:
        return dict(I=np.nan, p=np.nan, z=np.nan, n=int(ok.sum()))

    def _I(v):
        z = v - v.mean()
        num = np.sum(vals * z[rows] * z[cols])
        return (len(v) / vals.sum()) * num / np.sum(z ** 2)

    obs = _I(x)
    sim = np.empty(n_perm)
    for i in range(n_perm):
        sim[i] = _I(rng.permutation(x))
    # two-sided pseudo p-value
    p = (np.sum(np.abs(sim) >= abs(obs)) + 1) / (n_perm + 1)
    z = (obs - sim.mean()) / sim.std(ddof=1)
    return dict(I=float(obs), p=float(p), z=float(z), n=int(len(x)))


def local_morans(x, rows, cols, vals, n_perm, rng) -> pd.DataFrame:
    """LISA with conditional permutations, Benjamini–Hochberg corrected."""
    z = (x - x.mean())
    s2 = np.sum(z ** 2) / len(z)
    n = len(z)
    lag = np.zeros(n)
    np.add.at(lag, rows, vals * z[cols])
    Ii = z * lag / s2

    nb_count = np.bincount(rows, minlength=n)
    p = np.ones(n)
    for i in range(n):
        m = nb_count[i]
        if m == 0:
            continue
        others = np.delete(z, i)
        sim = np.array([z[i] * others[rng.integers(0, n - 1, m)].mean() / s2
                        for _ in range(n_perm)])
        p[i] = (np.sum(np.abs(sim) >= abs(Ii[i])) + 1) / (n_perm + 1)

    order = np.argsort(p)
    q = np.empty(n)
    q[order] = np.minimum.accumulate((p[order] * n / np.arange(1, n + 1))[::-1])[::-1]
    return pd.DataFrame(dict(Ii=Ii, p=p, q_fdr=np.clip(q, 0, 1)))


def spearman(a, b):
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 10:
        return np.nan, np.nan
    r, p = stats.spearmanr(a[ok], b[ok])
    return float(r), float(p)


def partial_spearman(a, b, ctrl):
    """ρ(a, b | ctrl) — rank-transform everything, then first-order partial."""
    ok = np.isfinite(a) & np.isfinite(b) & np.isfinite(ctrl)
    if ok.sum() < 12:
        return np.nan, np.nan
    ra, rb, rc = (stats.rankdata(v[ok]) for v in (a, b, ctrl))
    rab = np.corrcoef(ra, rb)[0, 1]
    rac = np.corrcoef(ra, rc)[0, 1]
    rbc = np.corrcoef(rb, rc)[0, 1]
    denom = np.sqrt((1 - rac ** 2) * (1 - rbc ** 2))
    if denom < 1e-12:
        return np.nan, np.nan
    r = (rab - rac * rbc) / denom
    n = ok.sum()
    t = r * np.sqrt((n - 3) / max(1 - r ** 2, 1e-12))
    p = 2 * stats.t.sf(abs(t), n - 3)
    return float(r), float(p)


def stars(p):
    if not np.isfinite(p):
        return ""
    return "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""


# ----------------------------------------------------------------------------
# b-value
# ----------------------------------------------------------------------------

def b_tinti(mags: np.ndarray, mc: float, dM: float = 0.0):
    """Tinti & Mulargia (1987) MLE. dM = 0 gives the continuous (Aki–Utsu) form.

        binned:     b = log10(1 + dM/(M̄ − Mc)) / dM      <- Mc = NOMINAL LOWEST BIN
        continuous: b = log10(e) / (M̄ − Mc)

    NO half-bin shift in the binned branch. `Mc − dM/2` is the Utsu/Bender
    continuous approximation; applying it *inside* the Tinti–Mulargia form
    double-corrects. Measured on 296,964 events from these catalogues, whose
    true b is exactly 1.000 by construction:

        binned TM, Mc = 3.6   (this form)      b = 1.0019   <- correct
        binned TM, Mc = 3.55  (double-corr.)   b = 0.8979   <- biased -0.102
        continuous, Mc = 3.6                   b = 1.1268   <- biased +0.127

    Returns (b, sigma_b) with sigma_b from Shi & Bolt (1982).
    """
    m = mags[mags >= mc - 1e-9]
    n = m.size
    if n < 25:
        return np.nan, np.nan
    mbar = m.mean()
    if mbar - mc <= 1e-6:
        return np.nan, np.nan
    if dM > 0:
        b = np.log10(1 + dM / (mbar - mc)) / dM
    else:
        b = np.log10(np.e) / (mbar - mc)
    se = 2.30 * b ** 2 * np.sqrt(np.sum((m - mbar) ** 2) / (n * (n - 1)))
    return float(b), float(se)


def maxc(mags: np.ndarray, bin_w: float = 0.1) -> float:
    """MAXC: magnitude of the modal bin of the non-cumulative FMD."""
    if mags.size < 50:
        return np.nan
    lo, hi = np.floor(mags.min() / bin_w) * bin_w, np.ceil(mags.max() / bin_w) * bin_w
    edges = np.arange(lo, hi + bin_w, bin_w)
    h, _ = np.histogram(mags, edges)
    return float(edges[int(np.argmax(h))] + bin_w / 2)


def knn_b_field(ev_lon, ev_lat, ev_mag, grid_xy, k, mc, dM, track, k_mc, off):
    """k-NN smoothed b at every grid point.

    Track 1: fixed Mc for every point.
    Track 2: local Mc = MAXC + off estimated on a DISJOINT k_mc neighbourhood,
             then the k nearest surviving events are re-selected. Disjoint =
             the Mc estimate does not reuse the same events as the b estimate,
             which is what stops the completeness step from manufacturing the
             very b-bias it is meant to remove.
    """
    n_ev = ev_lon.size
    if n_ev < k:
        nan = np.full(len(grid_xy), np.nan)
        return nan, nan.copy(), nan.copy()

    lat0 = float(np.mean(ev_lat))
    kx, ky = 111.320 * np.cos(np.radians(lat0)), 110.574
    ev_xy = np.column_stack([ev_lon * kx, ev_lat * ky])
    g_xy = np.column_stack([grid_xy[:, 0] * kx, grid_xy[:, 1] * ky])

    tree = cKDTree(ev_xy)
    b = np.full(len(g_xy), np.nan)
    se = np.full(len(g_xy), np.nan)
    rk = np.full(len(g_xy), np.nan)

    kq = min(max(k, k_mc if track == 2 else k), n_ev)
    dist, idx = tree.query(g_xy, k=kq)

    for i in range(len(g_xy)):
        d_i, id_i = dist[i], idx[i]
        if track == 1:
            sel = id_i[:k]
            mc_i = mc
            rk[i] = d_i[min(k, kq) - 1]
        else:
            n_mc = min(k_mc, n_ev)
            mc_i = maxc(ev_mag[id_i[:n_mc]]) + off
            if not np.isfinite(mc_i):
                continue
            surv = id_i[ev_mag[id_i] >= mc_i - 1e-9]
            if surv.size < k:
                continue
            sel = surv[:k]
            rk[i] = np.linalg.norm(ev_xy[sel[-1]] - g_xy[i])
        b[i], se[i] = b_tinti(ev_mag[sel], mc_i, dM)
    return b, se, rk


def thin_points(xy_deg: np.ndarray, min_sep_km: float, rng) -> np.ndarray:
    """Greedy farthest-first thinning so retained points are >= min_sep apart.

    Report §2.5: without this, k-NN smoothing manufactures spatial
    autocorrelation and Moran's I is inflated. Greedy from a fixed RNG so the
    thinned set is reproducible.
    """
    lat0 = float(np.mean(xy_deg[:, 1]))
    kx, ky = 111.320 * np.cos(np.radians(lat0)), 110.574
    xy = np.column_stack([xy_deg[:, 0] * kx, xy_deg[:, 1] * ky])

    order = rng.permutation(len(xy))
    keep, kept_xy = [], []
    for i in order:
        if not kept_xy or np.min(np.linalg.norm(np.array(kept_xy) - xy[i], axis=1)) >= min_sep_km:
            keep.append(i)
            kept_xy.append(xy[i])
    return np.sort(np.array(keep))


# ----------------------------------------------------------------------------
# Fault distance
# ----------------------------------------------------------------------------

def fault_distance(lon, lat, shp: Path) -> np.ndarray:
    """Distance (km) from each point to the nearest USGS Quaternary fault trace."""
    try:
        import geopandas as gpd
    except ImportError:
        raise SystemExit("pip install geopandas")
    g = gpd.read_file(shp).to_crs("EPSG:3310")           # California Albers, metres
    verts = np.vstack([np.asarray(ls.coords)[:, :2]
                       for geom in g.geometry if geom is not None
                       for ls in (geom.geoms if geom.geom_type.startswith("Multi") else [geom])])
    pts = gpd.GeoSeries(gpd.points_from_xy(lon, lat), crs="EPSG:4326").to_crs("EPSG:3310")
    P = np.column_stack([pts.x.values, pts.y.values])
    d, _ = cKDTree(verts).query(P)
    return d / 1000.0


# ----------------------------------------------------------------------------
# Data access
# ----------------------------------------------------------------------------

_CA_POLY = {}


def in_california(lon, lat, shp: Path) -> np.ndarray:
    """Point-in-polygon against the largest polygon of california.shp.

    Mirrors compute_residual_bias_v7.m STEP 0, which takes the polygon with the
    most vertices and calls inpolygon. Without this mask the rectangle admits
    offshore and Nevada cells that the published analysis never included.
    """
    key = str(shp)
    if key not in _CA_POLY:
        import geopandas as gpd
        g = gpd.read_file(shp)
        geom = g.union_all() if hasattr(g, "union_all") else g.unary_union
        if geom.geom_type == "MultiPolygon":
            geom = max(geom.geoms, key=lambda p: len(p.exterior.coords))
        _CA_POLY[key] = geom
    poly = _CA_POLY[key]
    from shapely.geometry import Point
    return np.array([poly.contains(Point(x, y)) for x, y in zip(lon, lat)])


def load_mu(cfg: Cfg) -> pd.DataFrame:
    """True background rate field: SHIFT spatial PDF (sums to 1) × bg_total_yr.

    NOT the raw SHIFT grid — that is the TOTAL rate, calibrated to undeclustered
    GCMT, and using it as μ overshoots by ~5–9×. The PDF is the shape only.
    """
    mu = pd.read_csv(cfg.mu_csv)
    mu.columns = [c.lower() for c in mu.columns]
    mu = mu.rename(columns={"longitude": "lon", "latitude": "lat"})
    pdf_col = next(c for c in mu.columns if "pdf" in c or "prob" in c or c == "p")
    tot = mu[pdf_col].sum()
    assert abs(tot - 1.0) < 1e-3, f"PDF sums to {tot:.4f}, expected 1 — wrong column?"

    # CRITICAL: reproduce what the generator actually did. It kept only the cells
    # inside the simulation box and RENORMALISED the PDF over those, then
    # multiplied by bg_total_yr:
    #     simulate_ca_catalogs.py::load_background_field()
    #         sub = df[in_box];  w = sub.pdf / sub.pdf.sum();  rate = w * 11.0
    # The box holds 1750 of 1951 cells carrying 86.06% of the PDF mass. Using the
    # full-grid PDF here would understate mu by 1/0.8606 = 1.162 in every cell and
    # inflate R = (lambda_dec - mu)/mu accordingly.
    inbox = ((mu.lon >= cfg.lon_min) & (mu.lon <= cfg.lon_max) &
             (mu.lat >= cfg.lat_min) & (mu.lat <= cfg.lat_max))
    mu = mu[inbox].reset_index(drop=True)
    mu["pdf_box"] = mu[pdf_col] / mu[pdf_col].sum()
    mu["mu_yr"] = mu["pdf_box"] * cfg.bg_total_yr
    assert abs(mu.mu_yr.sum() - cfg.bg_total_yr) < 1e-6
    return mu


def read_catalogue(cfg: Cfg, cid: int) -> pd.DataFrame:
    """Load the complete catalogue that shard `cid` was computed from.

    NOTE the index convention. Shard files are numbered decl_cat_%05d with a
    1-BASED index into the sorted catalogue list, while the catalogue files are
    0-BASED: decl_cat_00001.mat <-> complete_catalog_0000.csv. Getting this
    wrong silently pairs every mask with the neighbouring catalogue.

    Rows are filtered to Mc and sorted exactly as load_catalog.m did, so row i
    here is row i of the shard's is_mainshock / is_background / mag arrays.
    """
    f = cfg.cat_dir / f"complete_catalog_{cid - 1:04d}.csv"
    cat = pd.read_csv(f)
    cat.columns = [c.lower() for c in cat.columns]
    cat = cat[cat.magnitude >= cfg.Mc - 1e-9]
    cat = cat.sort_values("time_days", kind="stable").reset_index(drop=True)
    # aliases the rest of this module expects
    cat["lon"] = cat["longitude"]
    cat["lat"] = cat["latitude"]
    cat["mag"] = cat["magnitude"]
    if cat["is_background"].dtype == object:
        cat["is_background"] = cat["is_background"].astype(str).str.strip().str.lower().eq("true")
    return cat


def iter_shards(cfg: Cfg, cat_ids=None):
    paths = sorted((cfg.root / "03_declustered_catalogs").glob("decl_cat_*.mat"))
    if getattr(cfg, "n_cat", 0):
        paths = paths[:cfg.n_cat]
    for p in paths:
        cid = int(p.stem.split("_")[-1])
        if cat_ids is not None and cid not in cat_ids:
            continue
        with h5py.File(p, "r") as f:
            yield cid, f


def read_res(f, standard_only=True):
    """Yield (method, label, is_standard, is_mainshock bool array) from a shard."""
    res = f["res"]
    n = res["method"].shape[0]
    for j in range(n):
        meth = "".join(chr(c) for c in f[res["method"][j][0]][:].ravel())
        std = bool(np.array(f[res["is_standard"][j][0]]).ravel()[0])
        if standard_only and not std:
            continue
        label = "".join(chr(c) for c in f[res["label"][j][0]][:].ravel())
        im = np.array(f[res["is_mainshock"][j][0]]).ravel().astype(bool)
        yield meth, label, std, im


# ----------------------------------------------------------------------------
# Analysis 1 — rate bias
# ----------------------------------------------------------------------------

PDF_DLON, PDF_DLAT = 0.25, 0.20        # native cell of CA_Spatial_PDF_ETAS.csv


def analysis_rate(cfg: Cfg):
    rng = np.random.default_rng(cfg.seed)
    mu = load_mu(cfg)

    # anchor on a real native cell EDGE so every PDF cell nests exactly in one bin
    dlon, dlat = cfg.rate_kx * PDF_DLON, cfg.rate_ky * PDF_DLAT
    lon0 = np.unique(mu.lon.values).min() - PDF_DLON / 2
    lat0 = np.unique(mu.lat.values).min() - PDF_DLAT / 2
    lon_edges = np.arange(lon0, mu.lon.max() + PDF_DLON, dlon)
    lat_edges = np.arange(lat0, mu.lat.max() + PDF_DLAT, dlat)
    ncell = (len(lat_edges) - 1) * (len(lon_edges) - 1)

    def cell_of(lon, lat):
        ix = np.digitize(lon, lon_edges) - 1
        iy = np.digitize(lat, lat_edges) - 1
        ok = (ix >= 0) & (ix < len(lon_edges) - 1) & (iy >= 0) & (iy < len(lat_edges) - 1)
        return np.where(ok, iy * (len(lon_edges) - 1) + ix, -1)

    mu_cell = np.zeros(ncell)
    np.add.at(mu_cell, cell_of(mu.lon.values, mu.lat.values), mu.mu_yr.values)

    methods = list(cfg.methods) + (["Undeclustered"] if cfg.include_undeclustered else [])
    acc = {m: [] for m in methods}
    acc_true = []

    for cid, f in iter_shards(cfg):
        cat = read_catalogue(cfg, cid)
        cat.columns = [c.lower() for c in cat.columns]
        cat = cat[cat.mag >= cfg.Mc - 1e-9]
        ci = cell_of(cat.lon.values, cat.lat.values)
        is_bg = np.array(f["is_background"]).ravel().astype(bool)

        cnt_true = np.bincount(ci[is_bg & (ci >= 0)], minlength=ncell)
        acc_true.append(cnt_true / cfg.T_years)

        if cfg.include_undeclustered:
            acc["Undeclustered"].append(np.bincount(ci[ci >= 0], minlength=ncell) / cfg.T_years)

        for meth, _lab, _std, im in read_res(f, cfg.standard_only):
            if meth not in acc:
                continue
            sel = im & (ci >= 0)
            acc[meth].append(np.bincount(ci[sel], minlength=ncell) / cfg.T_years)

    lam_true = np.array(acc_true)                    # (n_real, ncell)

    iy, ix = np.divmod(np.arange(ncell), len(lon_edges) - 1)
    cent_lon = (lon_edges[:-1] + dlon / 2)[ix]
    cent_lat = (lat_edges[:-1] + dlat / 2)[iy]

    # valid_mask = poly_mask & (mu_50yr >= MIN_EXP_COUNT)   [v7 line 124]
    valid = (mu_cell * cfg.T_years >= cfg.min_exp_count) & in_california(
        cent_lon, cent_lat, cfg.ca_shp)
    print(f"  valid cells: {valid.sum()} of {ncell} "
          f"({dlon:g} x {dlat:g} deg = {cfg.rate_kx}x{cfg.rate_ky} native, "
          f"mu*{cfg.T_years:.0f} >= {cfg.min_exp_count}, in CA polygon, "
          f"estimator={cfg.rate_estimator})")
    dfault = fault_distance(cent_lon[valid], cent_lat[valid], cfg.fault_shp)
    logmu = np.log10(mu_cell[valid])

    rows, curves, maps = [], [], {}
    rw, cl, wv = queen_weights(np.column_stack([iy[valid], ix[valid]]))

    for meth in methods:
        if not acc[meth]:
            continue
        lam = np.array(acc[meth])[:, valid]
        R = (lam - mu_cell[valid]) / mu_cell[valid]           # (n_real, n_valid)
        Rmed = np.median(R, 0)                                # kept for reference only
        # Rest is what every statistic below uses. With "mean" this is exactly the
        # pooled rate sum(counts)/(n_real*T) expressed as a residual, because R is
        # linear in lambda.
        Rest = R.mean(0) if cfg.rate_estimator == "mean" else Rmed
        Riqr = np.percentile(R, 75, 0) - np.percentile(R, 25, 0)
        maps[meth] = dict(R=R, med=Rmed, est=Rest, iqr=Riqr)

        # 3×IQR outlier removal before the tests (report §2.4)
        g = np.abs(Rest - np.median(Rest)) <= cfg.iqr_outlier * stats.iqr(Rest)
        Rt = np.where(g, Rest, np.nan)

        mi = morans_i(Rest[g], *_sub(rw, cl, wv, g), cfg.n_perm, rng)
        r_mu, p_mu = spearman(Rt, logmu)
        r_f, p_f = spearman(Rt, dfault)
        pc_f, pcp_f = partial_spearman(Rt, dfault, logmu)
        pc_m, pcp_m = partial_spearman(Rt, logmu, dfault)

        rows.append(dict(
            method=meth,
            mean_absR=np.nanmean(np.abs(Rest)), median_absR=np.nanmedian(np.abs(Rest)),
            morans_I=mi["I"], morans_p=mi["p"], morans_sig=stars(mi["p"]),
            rho_logmu=r_mu, rho_logmu_sig=stars(p_mu),
            rho_fault=r_f, rho_fault_sig=stars(p_f),
            pcorr_R_fault_given_logmu=pc_f, pcorr_fault_sig=stars(pcp_f),
            pcorr_R_logmu_given_fault=pc_m, pcorr_logmu_sig=stars(pcp_m),
            pct_cells_gt_halfIQR=100 * np.mean(np.abs(Rest) > Riqr / 2),
            n_cells=int(valid.sum()), n_real=R.shape[0],
            cell_dlon=dlon, cell_dlat=dlat, estimator=cfg.rate_estimator))

        # Figure 4: bias vs background rate, equal-count bins of log10 μ
        qs = np.quantile(logmu, np.linspace(0, 1, 13))
        bi = np.clip(np.digitize(logmu, qs[1:-1]), 0, 11)
        for k in range(12):
            m = bi == k
            if m.sum() < 3:
                continue
            v = 100 * R[:, m].ravel()
            curves.append(dict(method=meth, bin=k,
                               logmu_centre=float(np.mean(logmu[m])),
                               mean_pct=float(np.mean(v)), sd_pct=float(np.std(v)),
                               n_cells=int(m.sum())))

        lisa = local_morans(Rest[g], *_sub(rw, cl, wv, g), cfg.n_perm, rng)
        lisa["lon"] = cent_lon[valid][g]
        lisa["lat"] = cent_lat[valid][g]
        lisa.to_csv(cfg.out / f"lisa_rate_{meth}.csv", index=False)

    pd.DataFrame(rows).to_csv(cfg.out / "table2_rate_structure.csv", index=False)
    pd.DataFrame(curves).to_csv(cfg.out / "fig4_bias_vs_rate.csv", index=False)
    np.savez_compressed(cfg.out / "rate_residual_maps.npz",
                        lon=cent_lon[valid], lat=cent_lat[valid],
                        mu=mu_cell[valid], logmu=logmu, dfault=dfault,
                        **{f"R_{m}": maps[m]["R"] for m in maps},
                        **{f"med_{m}": maps[m]["med"] for m in maps},
                        **{f"est_{m}": maps[m]["est"] for m in maps},
                        **{f"iqr_{m}": maps[m]["iqr"] for m in maps},
                        estimator=cfg.rate_estimator, cell_dlon=dlon, cell_dlat=dlat)
    print(f"Analysis 1 done -> {cfg.out}")


def _sub(rows, cols, vals, mask):
    """Restrict a weights triple to a boolean subset and reindex."""
    rows = np.asarray(rows, dtype=np.intp); cols = np.asarray(cols, dtype=np.intp)
    idx = np.full(mask.shape[0], -1, dtype=np.intp)
    idx[np.where(mask)[0]] = np.arange(mask.sum())
    keep = mask[rows] & mask[cols]
    r, c, v = idx[rows[keep]], idx[cols[keep]], vals[keep]
    tot = np.bincount(r, weights=v, minlength=mask.sum())
    return r, c, v / np.maximum(tot[r], 1e-12)      # re-row-standardise


# ----------------------------------------------------------------------------
# Analysis 2 — b-value bias
# ----------------------------------------------------------------------------

def analysis_bvalue(cfg: Cfg, mc_list=(3.6, 4.0, 4.5)):
    rng = np.random.default_rng(cfg.seed)
    mu = load_mu(cfg)

    glon = np.arange(mu.lon.min(), mu.lon.max() + cfg.b_cell, cfg.b_cell)
    glat = np.arange(mu.lat.min(), mu.lat.max() + cfg.b_cell, cfg.b_cell)
    GX, GY = np.meshgrid(glon, glat)
    grid = np.column_stack([GX.ravel(), GY.ravel()])

    methods = list(cfg.methods) + (["Undeclustered"] if cfg.include_undeclustered else [])
    store = {(m, t, k, mc): [] for m in methods for t in (1, 2)
             for k in cfg.k_list for mc in mc_list}
    rk_store = []
    rk_acc, rk_cnt = {}, {}

    # ---- expensive per-realisation collection ---------------------------
    # 180 kNN solves per realisation (6 sources x 5 k x 2 tracks x 3 Mc), so at
    # 2500 realisations this is ~7 h serial. --shard i/N splits it across
    # independent processes; --merge then concatenates and runs the (cheap)
    # spatial statistics once on the pooled median.
    shard_i, shard_n = getattr(cfg, "shard_i", 0), getattr(cfg, "shard_n", 1)
    for n_done, (cid, f) in enumerate(iter_shards(cfg)):
        if shard_n > 1 and (n_done % shard_n) != shard_i:
            continue
        cat = read_catalogue(cfg, cid)
        cat.columns = [c.lower() for c in cat.columns]
        sets = {}
        if cfg.include_undeclustered:
            sets["Undeclustered"] = np.ones(len(cat), bool)
        for meth, _lab, _std, im in read_res(f, cfg.standard_only):
            if meth in methods:
                sets[meth] = im

        for meth, sel in sets.items():
            sub = cat[sel]
            for mc in mc_list:
                s = sub[sub.mag >= mc - 1e-9]
                for k in cfg.k_list:
                    for track in (1, 2):
                        b, se, rk = knn_b_field(s.lon.values, s.lat.values, s.mag.values,
                                                grid, k, mc, cfg.dM, track,
                                                cfg.k_mc, cfg.maxc_offset)
                        store[(meth, track, k, mc)].append(b)
                        # running mean radius per grid point, per configuration:
                        # needed to average mu over the SAME neighbourhood that
                        # produced b-hat (see the logmu_nbhd block below)
                        key = (meth, track, k, mc)
                        if key in rk_acc:
                            rk_acc[key] += np.nan_to_num(rk); rk_cnt[key] += np.isfinite(rk)
                        else:
                            rk_acc[key] = np.nan_to_num(rk).copy()
                            rk_cnt[key] = np.isfinite(rk).astype(float)
                        if k == cfg.k_primary and track == 1 and mc == cfg.Mc:
                            rk_store.append(rk)

    if shard_n > 1:
        part = cfg.out / "bparts"
        part.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            part / f"bpart_{shard_i:03d}.npz",
            rk=np.array(rk_store),
            **{f"{m}|{t}|{k}|{mc}": np.array(v) for (m, t, k, mc), v in store.items() if v})
        print(f"  shard {shard_i}/{shard_n}: wrote bpart_{shard_i:03d}.npz")
        return

    if getattr(cfg, "merge", False):
        part = cfg.out / "bparts"
        files = sorted(part.glob("bpart_*.npz"))
        assert files, f"no shard parts in {part}"
        acc, rks = {}, []
        for fp in files:
            z = np.load(fp)
            rks.append(z["rk"])
            for key in z.files:
                if key == "rk":
                    continue
                acc.setdefault(key, []).append(z[key])
        for key, chunks in acc.items():
            m, t, k, mc = key.split("|")
            store[(m, int(t), int(k), float(mc))] = list(np.concatenate(chunks, 0))
        rk_store = list(np.concatenate(rks))
        print(f"  merged {len(files)} parts -> "
              f"{len(next(iter(store.values())))} realisations")

    rk_med = np.nanmedian(np.array(rk_store))
    keep = thin_points(grid, rk_med, rng)
    gk = grid[keep]
    dfault_g = fault_distance(gk[:, 0], gk[:, 1], cfg.fault_shp)

    # μ on the (thinned) b-grid. TWO versions, because b-hat and mu are not
    # naturally on the same support: b-hat comes from the k nearest events, a disc of
    # median radius ~84 km covering ~28 background cells, while the nearest-cell mu is
    # a single 0.25 x 0.20 deg patch. Pairing them directly is an errors-in-variables
    # problem whose error is itself a function of mu: the neighbourhood mean is 1.23x
    # the single-cell value at the median but 2.65x at the 95th percentile, and
    # rho(ratio, log mu_cell) = -0.61, so the under-representation is worst in exactly
    # the quiet cells where the signal is claimed.
    #   logmu_cell : nearest single background cell   (what was used before)
    #   logmu_g    : mu averaged over the SAME k-NN disc that produced b-hat  <- used
    mu_tree = cKDTree(np.column_stack([mu.lon, mu.lat]))
    _, mi_idx = mu_tree.query(gk)
    logmu_cell = np.log10(np.maximum(mu.mu_yr.values[mi_idx], 1e-12))

    _lat0 = float(np.mean(mu.lat.values))
    _kx, _ky = 111.320 * np.cos(np.radians(_lat0)), 110.574
    _mu_km = cKDTree(np.column_stack([mu.lon.values * _kx, mu.lat.values * _ky]))
    _gk_km = np.column_stack([gk[:, 0] * _kx, gk[:, 1] * _ky])

    def _logmu_nbhd(radius_km):
        """mu averaged over the disc of the given per-point radius."""
        out = np.empty(len(_gk_km))
        for i, rr in enumerate(radius_km):
            idx = _mu_km.query_ball_point(_gk_km[i], max(float(rr), 1e-6))
            out[i] = mu.mu_yr.values[idx].mean() if idx else mu.mu_yr.values[mi_idx[i]]
        return np.log10(np.maximum(out, 1e-12))

    rk_mean = {key: np.where(rk_cnt[key] > 0, rk_acc[key] / np.maximum(rk_cnt[key], 1), np.nan)
               for key in rk_acc}

    rw, cl, wv = knn_weights(gk, 8)
    rows, scat = [], []

    for (meth, track, k, mc), arr in store.items():
        if not arr:
            continue
        B = np.array(arr)                              # (n_real, n_grid)
        bias = np.nanmedian(B - cfg.b_true, 0)[keep]

        rad = rk_mean.get((meth, track, k, mc))
        rad = np.full(len(gk), rk_med) if rad is None else rad[keep]
        logmu_g = _logmu_nbhd(rad)

        mi = morans_i(bias, rw, cl, wv, cfg.n_perm, rng)
        r_mu, p_mu = spearman(bias, logmu_g)          # matched support  <- reported
        r_mu_c, p_mu_c = spearman(bias, logmu_cell)   # single cell, for comparison
        r_f, p_f = spearman(bias, dfault_g)

        rows.append(dict(method=meth, track=track, k=k, mc=mc,
                         morans_I=mi["I"], morans_p=mi["p"], morans_sig=stars(mi["p"]),
                         rho_logmu=r_mu, rho_logmu_sig=stars(p_mu),
                         rho_logmu_cell=r_mu_c, rho_logmu_cell_sig=stars(p_mu_c),
                         knn_radius_km=float(np.nanmedian(rad)),
                         rho_fault=r_f, rho_fault_sig=stars(p_f),
                         mean_abs_bias=np.nanmean(np.abs(bias)),
                         median_abs_bias=np.nanmedian(np.abs(bias)),
                         n_thinned=len(gk), thin_sep_km=rk_med,
                         power_rho015=_power(len(gk), 0.15),
                         power_rho020=_power(len(gk), 0.20)))

        if k == cfg.k_primary and mc == cfg.Mc:
            scat.append(pd.DataFrame(dict(method=meth, track=track,
                                          lon=gk[:, 0], lat=gk[:, 1],
                                          b_bias=bias, logmu=logmu_g,
                                          logmu_cell=logmu_cell,
                                          knn_radius_km=rad,
                                          dfault_km=dfault_g)))

    pd.DataFrame(rows).to_csv(cfg.out / "table3_b_structure.csv", index=False)
    sc = pd.concat(scat, ignore_index=True)
    sc.to_csv(cfg.out / "fig7_fig8_b_scatter.csv", index=False)
    np.savez_compressed(cfg.out / "bvalue_maps.npz",
                        grid_lon=grid[:, 0], grid_lat=grid[:, 1], keep=keep,
                        **{f"b_{m}_T{t}_k{k}_mc{mc}": np.array(v)
                           for (m, t, k, mc), v in store.items() if v})
    print(f"Analysis 2 done -> {cfg.out}")


def _power(n, rho, alpha=0.05):
    """Power of a two-sided correlation test — the report's §4.3 caveat."""
    if n < 6:
        return np.nan
    z = np.arctanh(rho) * np.sqrt(n - 3)
    zc = stats.norm.ppf(1 - alpha / 2)
    return float(stats.norm.sf(zc - z) + stats.norm.cdf(-zc - z))


# ----------------------------------------------------------------------------
# Analysis 3 — compounding
# ----------------------------------------------------------------------------

def analysis_compound(cfg: Cfg):
    R = np.load(cfg.out / "rate_residual_maps.npz")
    sc = pd.read_csv(cfg.out / "fig7_fig8_b_scatter.csv")
    sc = sc[sc.track == 1]

    tree = cKDTree(np.column_stack([R["lon"], R["lat"]]))
    rows = []
    for meth, g in sc.groupby("method"):
        key = f"med_{meth}"
        if key not in R:
            continue
        _, idx = tree.query(np.column_stack([g.lon, g.lat]))
        r, p = spearman(R[key][idx], g.b_bias.values)
        rows.append(dict(method=meth, rho_R_bbias=r, p_value=p, n=len(g),
                         conclusion=("compounding" if p < 0.05 and r > 0 else
                                     "cancellation" if p < 0.05 and r < 0 else
                                     "no compounding detected (NS)")))
    df = pd.DataFrame(rows)
    df.to_csv(cfg.out / "table4_compounding.csv", index=False)
    print(df.to_string(index=False))


# ----------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="all",
                    choices=["rate", "bvalue", "compound", "all"])
    ap.add_argument("--config", type=Path)
    ap.add_argument("--kx", type=int, default=0,
                    help="rate-grid width in NATIVE cells (1 = 0.25 deg lon)")
    ap.add_argument("--ky", type=int, default=0,
                    help="rate-grid height in NATIVE cells (1 = 0.20 deg lat)")
    ap.add_argument("--estimator", default="", choices=["", "mean", "median"],
                    help="per-cell estimator across realisations (default mean)")
    ap.add_argument("--cell", type=float, default=0.0, help=argparse.SUPPRESS)
    ap.add_argument("--tag", default="",
                    help="output subdir suffix, e.g. 0p25 -> metrics_0p25")
    ap.add_argument("--shard", default="",
                    help="i/N -- compute only realisations i::N and save a part")
    ap.add_argument("--merge", action="store_true",
                    help="merge bparts/ and run the spatial statistics")
    ap.add_argument("--n-cat", type=int, default=0,
                    help="use only the first N realisations (0 = all 2500). "
                         "The v6 report used 100.")
    a = ap.parse_args()

    cfg = Cfg()
    if a.n_cat:
        cfg.n_cat = a.n_cat
    if a.cell:
        cfg.rate_cell = a.cell
    if a.kx: cfg.rate_kx = a.kx
    if a.ky: cfg.rate_ky = a.ky
    if a.estimator: cfg.rate_estimator = a.estimator
    if a.shard:
        i, n = a.shard.split("/")
        cfg.shard_i, cfg.shard_n = int(i), int(n)
    cfg.merge = a.merge
    if a.tag:
        cfg.out = cfg.root / f"metrics_{a.tag}"
        cfg.out.mkdir(parents=True, exist_ok=True)
    if a.config:
        for k, v in json.loads(a.config.read_text()).items():
            setattr(cfg, k, Path(v) if k.endswith(("dir", "csv", "shp", "root")) else v)

    if a.stage in ("rate", "all"):
        analysis_rate(cfg)
    if a.stage in ("bvalue", "all"):
        analysis_bvalue(cfg)
    if a.stage in ("compound", "all"):
        analysis_compound(cfg)


if __name__ == "__main__":
    main()
