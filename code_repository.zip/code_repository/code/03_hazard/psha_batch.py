#!/usr/bin/env python3
"""Run the full 7-source x N-realisation PSHA sweep and collect hazard results.

Each job runs single-process (OQ_DISTRIBUTE=no) with a private database, and the
parallelism is in the outer pool. See the comments in one() for why.
"""
import argparse, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed
import os
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
from psha_run import write_inputs

REPO = Path(__file__).resolve().parents[2]          # repository root
DATA = Path(os.environ.get("DATA_DIR", REPO.parent / "data_archive"))   # data folder
B = DATA
SRC = ["truth", "GK74", "Gruenthal", "Uhrhammer", "Zaliapin", "Reasenberg", "complete"]
# Salton Trough was dropped 2026-09-01. Stored 3-site results keep their
# column/rows; they are simply never read.
SITES = {"San Francisco": (-122.42, 37.77),
         "Sacramento": (-121.49, 38.58)}

def one(job):
    # fields dir travels in the job tuple, not a module global: ProcessPoolExecutor
    # re-imports this module under spawn/forkserver and a global would reset.
    src, r, fields = job
    f = B / fields / src / f"fields_{r:04d}.csv"      # e.g. --fields 06_psha_source_models
    if not f.exists(): return None
    wd = Path(tempfile.mkdtemp(prefix=f"oq_{src}_{r}_", dir="/tmp"))
    # OQ_DATADIR isolates the calc HDF5 files but NOT the job database, which
    # defaults to ~/oqdata/db.sqlite3 for every process. With 12 concurrent jobs
    # against one 145 MB sqlite file they all block on the write lock and the
    # sweep stalls at zero CPU. [dbserver] file is overridable through a private
    # openquake.cfg pointed at by OQ_CONFIG_FILE, so give each job its own.
    (wd / "db").mkdir(parents=True, exist_ok=True)
    cfg = wd / "openquake.cfg"
    cfg.write_text(f"[dbserver]\nfile = {wd / 'db' / 'db.sqlite3'}\nmulti_user = false\n")
    # OQ_DISTRIBUTE=no keeps each job single-process. These jobs are small
    # (~350 point sources, 3 sites, 20 IMLs) so OQ's inner worker pool is pure
    # overhead: 67 CPU-s per run parallel against 4.1 CPU-s serial, and a dozen
    # concurrent inner pools exhausted RAM and killed runs with MemoryError.
    # Parallelism belongs in the outer ProcessPoolExecutor, one job per core.
    env = dict(os.environ, OQ_DATADIR=str(wd / "db"), OQ_CONFIG_FILE=str(cfg),
               OQ_DISTRIBUTE="no", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
               OPENBLAS_NUM_THREADS="1")
    try:
        nsrc = write_inputs(f, wd)
        p = subprocess.run(["oq", "engine", "--run", "job.ini", "--exports", "csv"],
                           cwd=wd, capture_output=True, text=True, env=env, timeout=900)
        if p.returncode != 0: return ({"source": src, "real": r, "error": p.stderr[-300:]}, [])
        out, curves = {}, []
        g = list((wd / "output").glob("hazard_curve-mean-PGA_*.csv"))
        if g:
            d = pd.read_csv(g[0], skiprows=1)
            imls = [c for c in d.columns if c.startswith("poe-")]
            for name, (lo, la) in SITES.items():
                m = (d.lon.sub(lo).abs() < 1e-3) & (d.lat.sub(la).abs() < 1e-3)
                if m.any():
                    curves.append({"source": src, "real": r, "site": name,
                                   **{c: float(d.loc[m, c].iloc[0]) for c in imls}})
        for tag, key in (("475y", "PGA475"), ("2475y", "PGA2475")):
            g = list((wd / "output").glob(f"hazard_map-mean-{tag}_*.csv"))
            if not g: continue
            d = pd.read_csv(g[0], skiprows=1)
            for name, (lo, la) in SITES.items():
                m = (d.lon.sub(lo).abs() < 1e-3) & (d.lat.sub(la).abs() < 1e-3)
                if m.any(): out[(name, key)] = float(d.loc[m, "PGA"].iloc[0])
        return ({"source": src, "real": r, "n_sources": nsrc,
                 **{f"{k[0]}|{k[1]}": v for k, v in out.items()}}, curves)
    except Exception as e:
        return ({"source": src, "real": r, "error": str(e)[:300]}, [])
    finally:
        shutil.rmtree(wd, ignore_errors=True)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--workers", type=int, default=20)
    ap.add_argument("--fields", default="fields")
    ap.add_argument("--sources", default="",
                    help="comma-separated source names (default: the standard seven)")
    ap.add_argument("--out", default=str(DATA / "07_psha_results" / "hazard_summary.csv"))
    ap.add_argument("--resume", action="store_true",
                    help="skip (source, real) pairs already present in BOTH the summary "
                         "and the curve file, and append to them")
    a = ap.parse_args()
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    srcs = [x.strip() for x in a.sources.split(",") if x.strip()] or SRC
    jobs = [(s, r, a.fields) for r in range(a.n) for s in srcs]
    print(f"{len(jobs)} runs, {a.workers} workers")
    # curve file must track the summary name, or every variant sweep overwrites
    # the same hazard_curves.csv and only the last one to finish survives
    _n = Path(a.out).name
    curve_out = str(Path(a.out).with_name(
        _n.replace("hazard_summary", "hazard_curves") if "hazard_summary" in _n
        else Path(a.out).stem + "_curves" + Path(a.out).suffix))
    # the curve file is written AFTER the summary, so if the two names collide the
    # curves silently overwrite the summary. Refuse rather than destroy the result.
    assert curve_out != str(a.out), f"curve file would overwrite the summary: {a.out}"
    # ---- resume ---------------------------------------------------------------
    # A (source, real) pair counts as done only when it is in BOTH files. The curve
    # file used to be written once at the very end, so a killed run left a summary
    # with no curves; resuming on the summary alone would then skip those jobs and
    # the curves would be missing for good.
    rows, crows, done = [], [], 0
    skip = set()
    if a.resume:
        def _load(p):
            f = Path(p)
            return pd.read_csv(f) if f.exists() and f.stat().st_size else None
        ds, dc = _load(a.out), _load(curve_out)
        if ds is not None and dc is not None:
            have = (set(map(tuple, ds[["source", "real"]].values))
                    & set(map(tuple, dc[["source", "real"]].values)))
            skip = {(str(s_), int(r_)) for s_, r_ in have}
            keep_s = ds.apply(lambda q: (str(q["source"]), int(q["real"])) in skip, axis=1)
            keep_c = dc.apply(lambda q: (str(q["source"]), int(q["real"])) in skip, axis=1)
            rows = ds[keep_s].to_dict("records")
            crows = dc[keep_c].to_dict("records")
        print(f"resume: {len(skip)} (source, real) pairs already complete")
    jobs = [j for j in jobs if (j[0], j[1]) not in skip]
    print(f"{len(jobs)} runs to do, {a.workers} workers", flush=True)

    def _flush():
        pd.DataFrame(rows).to_csv(a.out, index=False)
        pd.DataFrame(crows).to_csv(curve_out, index=False, float_format="%.6g")

    with ProcessPoolExecutor(a.workers) as ex:
        futs = {ex.submit(one, j): j for j in jobs}
        for fu in as_completed(futs):
            res = fu.result(); done += 1
            if res:
                x, cv = res
                if x: rows.append(x)
                crows.extend(cv)
            if done % 200 == 0:
                print(f"  {done}/{len(jobs)}", flush=True)
                _flush()          # BOTH files, so a kill never loses the curves
    _flush()
    df = pd.DataFrame(rows)
    print(f"wrote {curve_out}  rows={len(crows)}")
    print(f"wrote {a.out}  rows={len(df)}  errors={df.get('error', pd.Series(dtype=object)).notna().sum()}")
