#!/usr/bin/env python3
"""The NEW bias measures and their relations, in the SAME functional forms that folders
02, 03 and 06 established against background rate, with strain or fault distance
substituted for mu.

    measure          established in   form fitted                      correction
    ---------------  ---------------  ------------------------------   ----------------
    density ratio    U3 (folder 02)   log10(D_dec/D_true) = a+b*log10P  DIVISIVE
    residual power   U5 (folder 03)   log10(lam-mu)       = a+b*log10P  subtractive
    residual linear  U9 (folder 06)   (lam-mu)            = a+b*P       subtractive

The previous version of this file fitted the density DIFFERENCE linearly and the raw
residual against log P with a quadratic. Neither matched the relation the review had
established, so the corrections built on them were not the ones being tested.

CAVEAT carried through: the residual POWER form needs a positive residual and therefore
drops Gruenthal's 4 negative cells, exactly as folder 03 did. The residual LINEAR form
keeps every cell. ALL THREE are carried to hazard, because the relation figures U14/U15
show the power form fits strain far better than the linear one (R2 0.79-0.80 vs
0.60-0.66) and the result should not rest on the weaker of the two.

SECOND CAVEAT, measured in clipping_diagnostic.csv: both SUBTRACTIVE forms are ill-posed
on the full source grid. The relations are fitted on the 185 well-populated analysis cells
where mu is defined, but applied to every occupied cell (~429), many holding one or two
events in 100 yr (lambda ~ 0.01 ev/yr). A fitted ABSOLUTE residual of 0.05-0.1 ev/yr then
exceeds the whole cell, so 36-69 % of cells clip to the floor and their mass is
renormalised onto the survivors. The DIVISIVE density-ratio form is scale-free and clips
none. Read every subtractive result against that number.
"""
import numpy as np, pandas as pd
from scipy.spatial import cKDTree

from pathlib import Path
import os
GSRM = str(Path(os.environ.get("DATA_DIR", Path(__file__).resolve().parents[3] / "data_archive")) / "09_auxiliary" / "GSRM_average_strain_v2.1-20150901.txt")
METHODS = ["GK74", "Gruenthal", "Uhrhammer", "Zaliapin", "Reasenberg"]
# name -> (y transform, x transform, how the correction uses it)
FORMS = {
    "density_ratio":   dict(ylab="$\\log_{10}(D_{dec}/D_{true})$", logy=True,  logx=True),
    "residual_power":  dict(ylab="$\\log_{10}(\\lambda_{dec}-\\mu)$", logy=True,  logx=True),
    "residual_linear": dict(ylab="$\\lambda_{dec}-\\mu$  (events yr$^{-1}$)",
                            logy=False, logx=False),
}


def strain_at(lon, lat):
    g = pd.read_csv(GSRM, sep=r"\s+", comment="#",
                    names=["lat","lon","exx","eyy","exy","sxx","syy","sxy",
                           "c1","c2","c3","e1","e2","azi"])
    g["lon"] = np.where(g.lon > 180, g.lon - 360, g.lon)
    g = g[(g.lon > -127) & (g.lon < -111) & (g.lat > 30) & (g.lat < 45)].copy()
    g["eII"] = np.sqrt(g.exx**2 + g.eyy**2 + 2*g.exy**2)
    _, i = cKDTree(np.column_stack([g.lon, g.lat])).query(np.column_stack([lon, lat]))
    return g.eII.values[i]


def xy(form, mu, est, P):
    """Return (x, y, mask) for one method under one form. mask flags usable cells."""
    lam = mu * (1.0 + est)
    if form == "density_ratio":
        r = (lam/lam.sum()) / (mu/mu.sum())
        ok = np.isfinite(r) & (r > 0) & (P > 0)
        return np.log10(P[ok]), np.log10(r[ok]), ok
    if form == "residual_power":
        d = lam - mu
        ok = np.isfinite(d) & (d > 0) & (P > 0)
        return np.log10(P[ok]), np.log10(d[ok]), ok
    if form == "residual_linear":
        d = lam - mu
        ok = np.isfinite(d) & np.isfinite(P)
        return P[ok], d[ok], ok
    raise ValueError(form)


def fit(form, mu, est, P):
    x, y, ok = xy(form, mu, est, P)
    b, a = np.polyfit(x, y, 1)
    pred = a + b*x
    r2 = 1 - np.sum((y-pred)**2)/np.sum((y-y.mean())**2)
    return dict(a=a, b=b, R2=r2, n_used=int(ok.sum()), n_dropped=int((~ok).sum()))


def apply_correction(form, coef, lam, P):
    """Return a corrected, UNNORMALISED shape weight for the cells given."""
    a, b = coef["a"], coef["b"]
    if form == "density_ratio":
        ratio = 10.0**(a + b*np.log10(np.maximum(P, 1e-9)))     # D_dec/D_true predicted
        w = lam / np.maximum(ratio, 1e-6)                        # DIVIDE it out
    elif form == "residual_power":
        w = lam - 10.0**(a + b*np.log10(np.maximum(P, 1e-9)))    # SUBTRACT the residual
    elif form == "residual_linear":
        w = lam - (a + b*P)
    else:
        raise ValueError(form)
    return np.clip(w, 1e-9, None)
