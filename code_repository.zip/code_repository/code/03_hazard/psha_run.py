#!/usr/bin/env python3
"""Build OpenQuake inputs from a field file and run one classical PSHA.

Mirrors California_Results/psha/job.ini + gmpeLT.xml + OQ_Analysis3/prepare_inputs.py:
  classical mode, BooreEtAl2014 single branch (no GMPE logic tree, deliberately),
  20 PGA levels 0.005-3.0 g, truncation 3 sigma, max distance 200 km,
  investigation_time 50 yr, PoE 0.10 / 0.02, Vs30 360 m/s at 3 sites,
  point sources: 5-20 km seismogenic layer, 10 km hypocentre, two vertical
  strike-slip nodal planes at 0/90 equal weight, WC1994 scaling.
Mmax = 8.5 to match the generator's cap (v6 used 8.0).
"""
import argparse, os, subprocess, sys, shutil
import numpy as np, pandas as pd
from pathlib import Path

MC, MMAX, DEPTH = 3.6, 8.5, 10.0
# Salton Trough was dropped 2026-09-01. Stored 3-site results keep their
# column/rows; they are simply never read.
SITES = [(-122.42, 37.77), (-121.49, 38.58)]

def write_inputs(field_csv: Path, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(field_csv)
    d = d[(d["lambda"] > 0) & np.isfinite(d.b) & (d.b > 0)]
    L = ['<?xml version="1.0" encoding="utf-8"?>',
         '<nrml xmlns="http://openquake.org/xmlns/nrml/0.5" xmlns:gml="http://www.opengis.net/gml">',
         '<sourceModel name="ca_grid">',
         '  <sourceGroup name="Active Shallow Crust" tectonicRegion="Active Shallow Crust">']
    for i, s in enumerate(d.itertuples(index=False)):
        a_val = np.log10(s._2) + s.b * MC          # a = log10(rate) + b*Mc
        L += [f'    <pointSource id="s{i}" name="c{i}" tectonicRegion="Active Shallow Crust">',
              '      <pointGeometry>',
              f'        <gml:Point><gml:pos>{s.lon:.4f} {s.lat:.4f}</gml:pos></gml:Point>',
              '        <upperSeismoDepth>5.0</upperSeismoDepth>',
              '        <lowerSeismoDepth>20.0</lowerSeismoDepth>',
              '      </pointGeometry>',
              '      <magScaleRel>WC1994</magScaleRel>',
              '      <ruptAspectRatio>1.0</ruptAspectRatio>',
              f'      <truncGutenbergRichterMFD aValue="{a_val:.6f}" bValue="{s.b:.6f}" '
              f'minMag="{MC}" maxMag="{MMAX}"/>',
              '      <nodalPlaneDist>',
              '        <nodalPlane probability="0.5" strike="0.0" dip="90.0" rake="0.0"/>',
              '        <nodalPlane probability="0.5" strike="90.0" dip="90.0" rake="0.0"/>',
              '      </nodalPlaneDist>',
              f'      <hypoDepthDist><hypoDepth probability="1.0" depth="{DEPTH}"/></hypoDepthDist>',
              '    </pointSource>']
    L += ['  </sourceGroup>', '</sourceModel>', '</nrml>']
    (outdir / "source_model.xml").write_text("\n".join(L))
    (outdir / "ssmLT.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<nrml xmlns="http://openquake.org/xmlns/nrml/0.5">\n'
        '  <logicTree logicTreeID="lt1"><logicTreeBranchSet uncertaintyType="sourceModel" branchSetID="bs1">\n'
        '    <logicTreeBranch branchID="b1"><uncertaintyModel>source_model.xml</uncertaintyModel>'
        '<uncertaintyWeight>1.0</uncertaintyWeight></logicTreeBranch>\n'
        '  </logicTreeBranchSet></logicTree></nrml>\n')
    (outdir / "gmpeLT.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<nrml xmlns="http://openquake.org/xmlns/nrml/0.5">\n'
        '  <logicTree logicTreeID="lt2"><logicTreeBranchSet uncertaintyType="gmpeModel" branchSetID="bs1"\n'
        '      applyToTectonicRegionType="Active Shallow Crust">\n'
        '    <logicTreeBranch branchID="b1"><uncertaintyModel>BooreEtAl2014</uncertaintyModel>'
        '<uncertaintyWeight>1.0</uncertaintyWeight></logicTreeBranch>\n'
        '  </logicTreeBranchSet></logicTree></nrml>\n')
    (outdir / "sites.csv").write_text("lon,lat,vs30\n" + "".join(f"{a},{b},360\n" for a, b in SITES))
    (outdir / "job.ini").write_text(f"""[general]
description = decl PSHA {field_csv.parent.name} {field_csv.stem}
calculation_mode = classical
random_seed = 42
[geometry]
sites_csv = sites.csv
[logic_tree]
number_of_logic_tree_samples = 0
[erf]
rupture_mesh_spacing = 2.0
width_of_mfd_bin = 0.1
area_source_discretization = 10.0
[site_params]
reference_vs30_type = measured
reference_vs30_value = 360.0
reference_depth_to_2pt5km_per_sec = 2.0
reference_depth_to_1pt0km_per_sec = 50.0
[calculation]
source_model_logic_tree_file = ssmLT.xml
gsim_logic_tree_file = gmpeLT.xml
investigation_time = 50.0
intensity_measure_types_and_levels = {{"PGA": [0.005, 0.00707, 0.01, 0.01414, 0.02, 0.02828, 0.04, 0.05657, 0.08, 0.11314, 0.16, 0.22627, 0.32, 0.45255, 0.64, 0.90510, 1.28, 1.81019, 2.56, 3.0]}}
truncation_level = 3
maximum_distance = 200.0
[output]
mean = true
hazard_maps = true
uniform_hazard_spectra = false
poes = 0.1 0.02
export_dir = output
""")
    return len(d)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("field"); ap.add_argument("outdir")
    ap.add_argument("--run", action="store_true")
    a = ap.parse_args()
    n = write_inputs(Path(a.field), Path(a.outdir))
    print(f"{n} point sources -> {a.outdir}")
    if a.run:
        r = subprocess.run(["oq", "engine", "--run", "job.ini", "--exports", "csv"],
                           cwd=a.outdir, capture_output=True, text=True)
        print("rc", r.returncode); print(r.stdout[-2000:]); print(r.stderr[-2000:])
