#!/usr/bin/env python3
"""Build `A_truth` for 1000 realisations: the TRUE BACKGROUND catalogue in configuration A.

Configuration A is the traditional PSHA of each catalogue taken as it is -- its own annual
rate, its own k-NN b field and its own spatial density. `build_abc_fields.py` built that for
six sources (the five declustering algorithms and the complete catalogue) but not for the
true background catalogue, which is the seventh and is the one A should be read against:
in A the reference must also carry its own rate and b, or the comparison smuggles the rate
substitution in. `corrected_psha/fields/base/truth/` has it on the right grid but only for
300 realisations.

Everything here is `build_abc_fields.py`'s A branch with one change: the event mask is
`is_background` from the complete catalogue CSV rather than a declustering result. Grid,
k-NN b (k = 100, floor 25 events), Mc = 3.6, dM = 0.1 and the 100-year duration are
identical, and the first 300 realisations are checked against the stored fields.

    python3 build_a_truth_fields.py [N]        default N = 1000
"""
import sys
import numpy as np, pandas as pd
import os
from pathlib import Path
from scipy.spatial import cKDTree

REPO = Path(__file__).resolve().parents[2]          # repository root
DATA = Path(os.environ.get("DATA_DIR", REPO.parent / "data_archive"))   # data folder
B = REPO                     # only used for the optional cross-check against older fields
sys.path.insert(0, str(REPO / "code" / "02_rate_and_b_value"))
import bias_metrics as BM                                                  # noqa: E402

OUT = DATA / "06_psha_source_models" / "A_truth"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
MC, DM, DUR, K_NN, KNN_MIN = 3.6, 0.1, 100.0, 100, 25
PD_LON, PD_LAT = 0.25, 0.20
DLON, DLAT = 2 * PD_LON, 2 * PD_LAT

cfg = BM.Cfg(); mu_tab = BM.load_mu(cfg)
lon0 = np.unique(mu_tab.lon.values).min() - PD_LON / 2
lat0 = np.unique(mu_tab.lat.values).min() - PD_LAT / 2
lon_e = np.arange(lon0, mu_tab.lon.max() + PD_LON, DLON)
lat_e = np.arange(lat0, mu_tab.lat.max() + PD_LAT, DLAT)
nlon, nlat = len(lon_e) - 1, len(lat_e) - 1
ncell = nlon * nlat


def cell_of(lo, la):
    ix = np.digitize(lo, lon_e) - 1
    iy = np.digitize(la, lat_e) - 1
    ok = (ix >= 0) & (ix < nlon) & (iy >= 0) & (iy < nlat)
    return np.where(ok, iy * nlon + ix, -1)


iy, ix = np.divmod(np.arange(ncell), nlon)
CL = (lon_e[:-1] + DLON / 2)[ix]
CB = (lat_e[:-1] + DLAT / 2)[iy]


def knn_b(elon, elat, emag, clon, clat):
    if elon.size < KNN_MIN:
        return np.full(len(clon), np.nan)
    la0 = float(elat.mean())
    kx, ky = 111.320 * np.cos(np.radians(la0)), 110.574
    tree = cKDTree(np.column_stack([elon * kx, elat * ky]))
    kq = min(K_NN, elon.size)
    _, idx = tree.query(np.column_stack([clon * kx, clat * ky]), k=kq)
    if kq == 1:
        idx = idx[:, None]
    mb = emag[idx].mean(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        b = np.log10(1 + DM / (mb - MC)) / DM * (kq - 1) / kq
    b[~np.isfinite(mb) | (mb - MC <= 1e-6)] = np.nan
    return b


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    shards = sorted((DATA / "03_declustered_catalogs").glob("decl_cat_*.mat"))[:N]
    print(f"{ncell} cells ({nlon}x{nlat}), {len(shards)} realisations", flush=True)
    chk, bad = [], 0
    for r, sp in enumerate(shards):
        cid = int(sp.stem.split("_")[-1])
        cat = pd.read_csv(
            DATA / "02_synthetic_catalogs" / "complete_catalogs" / f"complete_catalog_{cid-1:04d}.csv",
            usecols=["latitude", "longitude", "magnitude", "is_background", "time_days"])
        cat = cat[cat.magnitude >= MC - 1e-9].sort_values(
            "time_days", kind="stable").reset_index(drop=True)
        # is_background is a real boolean in these CSVs; guard anyway, because the
        # string 'True'/'False' form is the classic way this column goes wrong
        bg = cat.is_background
        msk = bg.astype(bool).values if bg.dtype != object else \
            bg.astype(str).str.strip().str.lower().isin(["true", "1"]).values
        ci = cell_of(cat.longitude.values, cat.latitude.values)
        keep = msk & (ci >= 0)
        lo, la, mag = (cat.longitude.values[keep], cat.latitude.values[keep],
                       cat.magnitude.values[keep])
        kb = knn_b(lo, la, mag, CL, CB)
        u, c = np.unique(ci[keep], return_counts=True)
        lam = c / DUR
        good = np.isfinite(kb[u]) & (kb[u] > 0) & (kb[u] < 5) & (lam > 0)
        pd.DataFrame(dict(lon=CL[u][good], lat=CB[u][good], **{"lambda": lam[good]},
                          b=kb[u][good], n_events=c[good])).to_csv(
            OUT / f"fields_{r:04d}.csv", index=False, float_format="%.6g")
        ref = B / "corrected_psha" / "fields" / "base" / "truth" / f"fields_{r:04d}.csv"
        if ref.exists():
            a1 = pd.read_csv(OUT / f"fields_{r:04d}.csv")
            a2 = pd.read_csv(ref)
            ok = (len(a1) == len(a2)
                  and np.allclose(a1["lambda"], a2["lambda"], rtol=1e-9)
                  and np.allclose(a1.b, a2.b, rtol=1e-9))
            chk.append(ok)
            if not ok:
                bad += 1
        if (r + 1) % 200 == 0:
            print(f"  {r+1}/{len(shards)}", flush=True)
    print(f"identical to the stored corrected_psha/fields/base/truth: "
          f"{sum(chk)} of {len(chk)} compared ({bad} mismatched)")


if __name__ == "__main__":
    main()
