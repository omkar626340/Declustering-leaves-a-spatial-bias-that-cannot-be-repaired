#!/usr/bin/env python3
"""Build configuration C on the FOUR-NODE strain predictor, six sources x 1000 realisations.

Same recipe as `build_abc_fields.py`'s `<src>_kb_den_strain` -- the complete catalogue's
total rate and k-NN b field, with the declustered SHAPE divided by the fitted strain
relation -- with ONE change: the predictor is the mean of the four tied GSRM nodes over the
cell footprint instead of the arbitrary nearest node.

Why this is not a full rebuild. The corrected field is the raw field divided by the fitted
ratio and renormalised, and the raw fields (`<src>_kb_raw`) already exist for all 1000
realisations. Dividing a field by a per-cell factor and renormalising does not care about
the field's overall scale, so the corrected field can be derived exactly from the stored
raw one. The b column, the event counts and the total rate travel across untouched. That
turns a 1000-shard rebuild (~30 min of k-NN b) into a file copy with one multiplication,
and it is exact rather than approximate.

Why the predictor changes. `_bias.strain_at:52` takes the nearest GSRM node to the cell
centre, and that centre is a four-way tie in 185 analysis cells out of 185 (Check C). The
arbitrary pick drops the predictor's R^2 against log10(mu) from 0.961 to 0.833, and that is
what leaves a residual slope after the correction: 84-86 % of the trend removed instead of
93-97 % (tables/Table_correction_slope_removal.csv).

    python3 build_c_fournode_fields.py [N]      default N = 1000
"""
import sys
import numpy as np, pandas as pd
import os
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]          # repository root
DATA = Path(os.environ.get("DATA_DIR", REPO.parent / "data_archive"))   # data folder
sys.path.insert(0, str(REPO / "code" / "03_hazard"))
from _bias import apply_correction, fit as bias_fit                       # noqa: E402

FIELDS = DATA / "06_psha_source_models"
TAG_SRC, TAG_DST = "kb_raw", "kb_den_strain4"
SRC6 = ["GK74", "Gruenthal", "Uhrhammer", "Zaliapin", "Reasenberg", "Undeclustered"]
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
GSRM = str(DATA / "09_auxiliary" / "GSRM_average_strain_v2.1-20150901.txt")


_GSRM_CACHE = {}


def _gsrm():
    """Load and trim GSRM once. The first version of this file re-read the whole table on
    every call, and the per-realisation fallback for cells absent from realisation 0 called
    it thousands of times -- the build was heading for ~80 minutes instead of ~3."""
    if not _GSRM_CACHE:
        g = pd.read_csv(GSRM, sep=r"\s+", comment="#",
                        names=["lat", "lon", "exx", "eyy", "exy", "sxx", "syy", "sxy",
                               "c1", "c2", "c3", "e1", "e2", "azi"])
        g["lon"] = np.where(g.lon > 180, g.lon - 360, g.lon)
        g = g[(g.lon > -127) & (g.lon < -111) & (g.lat > 30) & (g.lat < 45)]
        _GSRM_CACHE["lon"] = g.lon.values
        _GSRM_CACHE["lat"] = g.lat.values
        _GSRM_CACHE["eII"] = np.sqrt(g.exx ** 2 + g.eyy ** 2 + 2 * g.exy ** 2).values
        _GSRM_CACHE["area"] = np.cos(np.radians(g.lat.values))
    return (_GSRM_CACHE["lon"], _GSRM_CACHE["lat"],
            _GSRM_CACHE["eII"], _GSRM_CACHE["area"])


def four_node_strain(lon, lat):
    """Mean of the GSRM nodes inside each 0.50 x 0.40 deg cell footprint, cos(lat)-weighted.
    Reproduces checkC_smoothed_strain.py:71-82 / ff_common.strain_cellmean."""
    gl, gb, ge, ar = _gsrm()
    out = np.full(len(lon), np.nan)
    for i, (x, y) in enumerate(zip(lon, lat)):
        m = (np.abs(x - gl) <= 0.25 + 1e-9) & (np.abs(y - gb) <= 0.20 + 1e-9)
        if m.any():
            out[i] = (ge[m] * ar[m]).sum() / ar[m].sum()
        else:                      # source cells outside the strain grid: nearest node
            j = np.argmin((gl - x) ** 2 + (gb - y) ** 2)
            out[i] = ge[j]
    return out


def main():
    # ---- refit the relation on the four-node predictor, same function as published ----
    z = np.load(DATA / "04_seismicity_rate" / "rate_residual_maps.npz",
                allow_pickle=True)
    P4_185 = four_node_strain(z["lon"], z["lat"])
    COEF, rows = {}, []
    for m in SRC6:
        f = bias_fit("density_ratio", z["mu"], z[f"est_{m}"], P4_185)
        COEF[m] = dict(a=f["a"], b=f["b"])
        rows.append(dict(source=m, a=f["a"], b=f["b"], R2=f["R2"], n_used=f["n_used"],
                         predictor="four-node cell-mean strain"))
    rel = pd.DataFrame(rows)
    tab = DATA / "06_psha_source_models" / "correction_coefficients"
    tab.mkdir(parents=True, exist_ok=True)
    rel.to_csv(tab / "E2b_correction_relations_fournode.csv", index=False,
               float_format="%.6g")
    print(rel.round(4).to_string(index=False), flush=True)

    # ---- one strain lookup for every cell that appears in any raw field ----
    # the union of cells over a SPREAD of realisations, not just the first: which cells are
    # occupied varies between realisations, and any cell missed here falls back to a fresh
    # footprint computation
    seen = {}
    for s in SRC6:
        for r in (0, 1, 2, 250, 500, 750, 999):
            f = FIELDS / f"{s}_{TAG_SRC}" / f"fields_{r:04d}.csv"
            if not f.exists():
                continue
            d = pd.read_csv(f, usecols=["lon", "lat"])
            for x, y in zip(d.lon.round(4), d.lat.round(4)):
                seen[(x, y)] = True
    keys = sorted(seen)
    P = dict(zip(keys, four_node_strain(np.array([k[0] for k in keys]),
                                        np.array([k[1] for k in keys]))))
    print(f"{len(keys)} distinct source cells; strain {min(P.values()):.1f} to "
          f"{max(P.values()):.1f} nanostrain/yr", flush=True)

    for s in SRC6:
        (FIELDS / f"{s}_{TAG_DST}").mkdir(parents=True, exist_ok=True)
    miss = 0
    for r in range(N):
        for s in SRC6:
            src = FIELDS / f"{s}_{TAG_SRC}" / f"fields_{r:04d}.csv"
            if not src.exists():
                miss += 1
                continue
            d = pd.read_csv(src)
            pp = np.array([P.get((round(x, 4), round(y, 4)), np.nan)
                           for x, y in zip(d.lon, d.lat)])
            if not np.isfinite(pp).all():          # a cell absent from realisation 0
                bad = ~np.isfinite(pp)
                pp[bad] = four_node_strain(d.lon.values[bad], d.lat.values[bad])
            lam = d["lambda"].values
            w = apply_correction("density_ratio", COEF[s], lam, pp)
            out = d.copy()
            out["lambda"] = w / w.sum() * lam.sum()      # same total rate as the raw field
            out.to_csv(FIELDS / f"{s}_{TAG_DST}" / f"fields_{r:04d}.csv",
                       index=False, float_format="%.6g")
        if (r + 1) % 200 == 0:
            print(f"  {r+1}/{N}", flush=True)
    print(f"done; {miss} missing raw fields skipped")


if __name__ == "__main__":
    main()
