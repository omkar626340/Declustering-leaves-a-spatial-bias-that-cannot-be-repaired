#!/usr/bin/env python3
"""E2(b) -- build every model of the A / B / C-strain / C-fault comparison for SIX sources
(the five algorithms plus the UNDECLUSTERED catalogue) on ALL 1000 realisations, plus the
true-shape reference. Reads only; writes only into review_work_SN/_fields2/.

The existing figure (review_work_UM/final_vs_truth.py, Figure U26) is built from
    A          corrected_psha/fields/base/<src>      300 realisations, five methods
    B, C       review_work_UM/fields_new/<m>_kb_*    300 realisations, five methods
    reference  review_work_UM/fields_new/truth_kb    300 realisations
so both the sixth source and realisations 300-999 are missing. Everything here is rebuilt
with the same rules:

    A_<src>              declustered rate + that source's own k-NN b field
                         (corrected_psha/build_corrected_fields.py:89-130, variant `base`)
    <src>_kb_raw         B: declustered SHAPE x the complete catalogue's rate,
                         + the complete catalogue's k-NN b
                         (review_work_UM/build_knnb_fields.py:72-95)
    <src>_kb_den_strain  C: B with the shape corrected by strain rate, divisive
    <src>_kb_den_fault   C: B with the shape corrected by fault distance, divisive
                         (_bias.apply_correction, form "density_ratio")
    truth_kb             reference: the TRUE background shape at the complete catalogue's
                         rate and b (review_work_UM/build_truth_kb.py:56-68)

For the undeclustered source B is, by construction, the same model as A: its shape IS the
complete catalogue's shape and B gives it the complete catalogue's rate and b. It is built
and run anyway, as an internal check that the two agree in hazard.

The correction coefficients for the five algorithms are carried over from
review_work_UM/07_correction_strain/tables/relations_strain.csv and
08_correction_fault/tables/relations_fault.csv; the UNDECLUSTERED row does not exist there
and is fitted here by the same function (_bias.fit, form "density_ratio") on the same
realisation-averaged field, with the five refitted alongside as a check.

    python3 build_abc_fields.py [N]        default N = 1000
"""
import sys
import h5py, numpy as np, pandas as pd
import os
from pathlib import Path
from scipy.spatial import cKDTree

REPO = Path(__file__).resolve().parents[2]          # repository root
DATA = Path(os.environ.get("DATA_DIR", REPO.parent / "data_archive"))   # data folder
B = REPO                     # only used for the optional cross-check against older fields
sys.path.insert(0, str(REPO / "code" / "03_hazard")); sys.path.insert(0, str(REPO / "code" / "02_rate_and_b_value"))
import bias_metrics as BM
from _bias import strain_at, apply_correction, fit as bias_fit

OUT = DATA / "06_psha_source_models"
TAB = DATA / "06_psha_source_models" / "correction_coefficients"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
MC, DM, DUR, K_NN, KNN_MIN = 3.6, 0.1, 100.0, 100, 25
PD_LON, PD_LAT = 0.25, 0.20
DLON, DLAT = 2 * PD_LON, 2 * PD_LAT
METHODS = ["GK74", "Gruenthal", "Uhrhammer", "Zaliapin", "Reasenberg"]
SRC6 = METHODS + ["Undeclustered"]
MASKNAME = {"Undeclustered": "complete"}

# ---- grid, exactly corrected_psha/build_corrected_fields.py:42-58 -------------------
cfg = BM.Cfg(); mu_tab = BM.load_mu(cfg)
lon0 = np.unique(mu_tab.lon.values).min() - PD_LON / 2
lat0 = np.unique(mu_tab.lat.values).min() - PD_LAT / 2
lon_e = np.arange(lon0, mu_tab.lon.max() + PD_LON, DLON)
lat_e = np.arange(lat0, mu_tab.lat.max() + PD_LAT, DLAT)
nlon, nlat = len(lon_e) - 1, len(lat_e) - 1; ncell = nlon * nlat


def cell_of(lo, la):
    ix = np.digitize(lo, lon_e) - 1; iy = np.digitize(la, lat_e) - 1
    ok = (ix >= 0) & (ix < nlon) & (iy >= 0) & (iy < nlat)
    return np.where(ok, iy * nlon + ix, -1)


mu_cell = np.zeros(ncell)
np.add.at(mu_cell, cell_of(mu_tab.lon.values, mu_tab.lat.values), mu_tab.mu_yr.values)
iy, ix = np.divmod(np.arange(ncell), nlon)
CL = (lon_e[:-1] + DLON / 2)[ix]; CB = (lat_e[:-1] + DLAT / 2)[iy]
gm = mu_cell > 0
shape_true = mu_cell[gm] / mu_cell[gm].sum()
lon_t, lat_t = CL[gm], CB[gm]


def knn_b(elon, elat, emag, clon, clat):        # build_corrected_fields.py:76-87
    if elon.size < KNN_MIN: return np.full(len(clon), np.nan)
    la0 = float(elat.mean()); kx, ky = 111.320 * np.cos(np.radians(la0)), 110.574
    tree = cKDTree(np.column_stack([elon * kx, elat * ky]))
    kq = min(K_NN, elon.size)
    _, idx = tree.query(np.column_stack([clon * kx, clat * ky]), k=kq)
    if kq == 1: idx = idx[:, None]
    mb = emag[idx].mean(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        b = np.log10(1 + DM / (mb - MC)) / DM * (kq - 1) / kq
    b[~np.isfinite(mb) | (mb - MC <= 1e-6)] = np.nan
    return b


# ---- correction relations: carry over the five, fit the sixth ----------------------
z = np.load(DATA / "04_seismicity_rate" / "rate_residual_maps.npz", allow_pickle=True)
mu185, est185 = z["mu"], {m: z[f"est_{m}"] for m in SRC6}
P185 = {"strain": strain_at(z["lon"], z["lat"]),
        "fault": np.maximum(BM.fault_distance(z["lon"], z["lat"], cfg.fault_shp), 0.5)}
STORED = {"strain": pd.read_csv(DATA / "06_psha_source_models" / "correction_coefficients" / "relations_strain.csv"),
          "fault": pd.read_csv(DATA / "06_psha_source_models" / "correction_coefficients" / "relations_fault.csv")}
rel_rows, COEF = [], {}
for pred in ("strain", "fault"):
    for m in SRC6:
        f = bias_fit("density_ratio", mu185, est185[m], P185[pred])
        COEF[(pred, m)] = dict(a=f["a"], b=f["b"])
        s = STORED[pred]
        s = s[(s.form == "density_ratio") & (s.method == m)]
        rel_rows.append(dict(predictor=pred, source=m, a=f["a"], b=f["b"], R2=f["R2"],
                             n_used=f["n_used"],
                             stored_a=float(s.a.iloc[0]) if len(s) else np.nan,
                             stored_b=float(s.b.iloc[0]) if len(s) else np.nan,
                             carried_over=bool(len(s))))
rel = pd.DataFrame(rel_rows)
TAB.mkdir(parents=True, exist_ok=True)
rel.to_csv(TAB / "E2b_correction_relations.csv", index=False, float_format="%.6g")
d = rel.dropna(subset=["stored_a"])
print(f"refit vs stored coefficients: max |da| = {np.abs(d.a - d.stored_a).max():.2e}, "
      f"max |db| = {np.abs(d.b - d.stored_b).max():.2e}")

VARS = ["kb_raw", "kb_den_strain", "kb_den_fault"]
for s in SRC6:
    (OUT / f"A_{s}").mkdir(parents=True, exist_ok=True)
    for v in VARS: (OUT / f"{s}_{v}").mkdir(parents=True, exist_ok=True)
(OUT / "truth_kb").mkdir(parents=True, exist_ok=True)

# Predictors on every grid cell, computed once. The coordinates are ROUNDED TO 4 dp
# first, because build_knnb_fields.py:16-31 keys its predictor cache on the rounded
# (lon, lat) read back from the field CSVs. That matters: these cell centres sit exactly
# between nodes of the 0.25 x 0.20 deg strain grid, so the nearest-node lookup inside
# _bias.strain_at:52 is a tie, and a difference of 1e-13 in the coordinate flips which
# node wins and changes the strain value materially. Rounding first reproduces the
# published fields exactly; see the note in the report.
S_ALL = strain_at(np.round(CL, 4), np.round(CB, 4))
D_ALL = np.maximum(BM.fault_distance(np.round(CL, 4), np.round(CB, 4), cfg.fault_shp), 0.5)

shards = sorted((DATA / "03_declustered_catalogs").glob("decl_cat_*.mat"))[:N]
print(f"{ncell} cells ({nlon}x{nlat}), {len(shards)} realisations", flush=True)
chk = []
for r, sp in enumerate(shards):
    cid = int(sp.stem.split("_")[-1])
    cat = pd.read_csv(DATA / "02_synthetic_catalogs" / "complete_catalogs" / f"complete_catalog_{cid-1:04d}.csv",
                      usecols=["latitude", "longitude", "magnitude", "is_background", "time_days"])
    cat = cat[cat.magnitude >= MC - 1e-9].sort_values("time_days", kind="stable").reset_index(drop=True)
    ci = cell_of(cat.longitude.values, cat.latitude.values)
    lo, la, mag = cat.longitude.values, cat.latitude.values, cat.magnitude.values
    sel = {"complete": np.ones(len(cat), bool)}
    with h5py.File(sp, "r") as f:
        res = f["res"]
        for j in range(res["method"].shape[0]):
            if not bool(np.array(f[res["is_standard"][j][0]]).ravel()[0]): continue
            m = "".join(chr(c) for c in f[res["method"][j][0]][:].ravel())
            if m in METHODS: sel[m] = np.array(f[res["is_mainshock"][j][0]]).ravel().astype(bool)

    kb, cells, lam_of = {}, {}, {}
    for s in SRC6:
        msk = sel[MASKNAME.get(s, s)] & (ci >= 0)
        kb[s] = knn_b(lo[msk], la[msk], mag[msk], CL, CB)
        u, c = np.unique(ci[msk], return_counts=True)
        cells[s], lam_of[s] = u, c / DUR
        good = np.isfinite(kb[s][u]) & (kb[s][u] > 0) & (kb[s][u] < 5) & (lam_of[s] > 0)
        pd.DataFrame(dict(lon=CL[u][good], lat=CB[u][good], **{"lambda": lam_of[s][good]},
                          b=kb[s][u][good], n_events=c[good])).to_csv(
            OUT / f"A_{s}" / f"fields_{r:04d}.csv", index=False, float_format="%.6g")
        ref = B / "corrected_psha" / "fields" / "base" / MASKNAME.get(s, s) / f"fields_{r:04d}.csv"
        if ref.exists():
            a1 = pd.read_csv(OUT / f"A_{s}" / f"fields_{r:04d}.csv"); a2 = pd.read_csv(ref)
            chk.append(len(a1) == len(a2) and np.allclose(a1["lambda"], a2["lambda"], rtol=1e-9)
                       and np.allclose(a1.b, a2.b, rtol=1e-9))

    # B and C: the complete catalogue's total rate and k-NN b field. The b lookup is the
    # one of build_knnb_fields.py:40-41,48-49 -- read from the complete catalogue's
    # written field rows, with that file's MEDIAN b where a cell is absent from it.
    cpl = pd.read_csv(OUT / "A_Undeclustered" / f"fields_{r:04d}.csv")
    N_total = float(cpl["lambda"].sum())
    bmap = dict(zip(zip(cpl.lon.round(4), cpl.lat.round(4)), cpl.b))
    b_fill = float(cpl.b.median())
    for s in SRC6:
        u = cells[s]; lam = lam_of[s]
        bb = np.array([bmap.get((round(x, 4), round(y, 4)), b_fill)
                       for x, y in zip(CL[u], CB[u])])
        out = {"kb_raw": lam / lam.sum()}
        for pred, P in (("strain", S_ALL[u]), ("fault", D_ALL[u])):
            v = apply_correction("density_ratio", COEF[(pred, s)], lam, P)
            out[f"kb_den_{pred}"] = v / v.sum()
        for tag, wgt in out.items():
            pd.DataFrame(dict(lon=CL[u], lat=CB[u], **{"lambda": wgt * N_total}, b=bb,
                              n_events=np.round(lam * DUR).astype(int))).to_csv(
                OUT / f"{s}_{tag}" / f"fields_{r:04d}.csv", index=False, float_format="%.6g")

    bt = np.array([bmap.get((round(x, 4), round(y, 4)), b_fill)
                   for x, y in zip(lon_t, lat_t)])        # build_truth_kb.py:62-65
    pd.DataFrame(dict(lon=lon_t, lat=lat_t, **{"lambda": shape_true * N_total}, b=bt,
                      n_events=np.round(shape_true * N_total * DUR).astype(int))).to_csv(
        OUT / "truth_kb" / f"fields_{r:04d}.csv", index=False, float_format="%.6g")
    if (r + 1) % 100 == 0: print(f"  {r+1}/{len(shards)}", flush=True)

print(f"model-A fields identical to the stored corrected_psha/fields/base: "
      f"{sum(chk)} of {len(chk)} compared")
print("done")
