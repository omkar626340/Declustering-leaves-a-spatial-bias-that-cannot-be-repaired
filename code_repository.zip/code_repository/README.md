# Code: "Declustering leaves a spatial bias that cannot be repaired"

Code for the background rate field, the seismicity-rate and b-value bias, and the hazard calculation. `README.pdf` is this README in full, with each file described: what it does, its inputs, its outputs and where it is used in the paper.

| folder | what it computes |
|---|---|
| `code/01_SHIFT_GSRM2/` | background rate field μ from the GSRM v2.1 strain rates, following the SHIFT-GSRM2 forecast of Bird and Kreemer (2015), model version 4 (d) (MATLAB); `parse_gcmt.py` prepares the Global CMT calibration catalogue |
| `code/02_rate_and_b_value/bias_metrics.py` | seismicity rate per 0.50° × 0.40° cell and its bias R = (λ − μ)/μ; b-value by the binned Tinti–Mulargia estimator from the k = 100 nearest events, and its bias |
| `code/03_hazard/` | hazard source models (traditional PSHA, the prescription, the fault and strain corrections, the exact-map reference), the OpenQuake input writer and the batch runner |

## Data

The data (background map, synthetic and declustered catalogues, bias fields, source models, hazard results, and the SHIFT-GSRM2 inputs) are kept separately in `data_archive/`. Point the code to it with

```
export DATA_DIR=/path/to/data_archive
```

or place `data_archive/` next to this repository folder.

## Running

```
# background field: run in MATLAB from the folder holding the inputs
cd data_archive/11_SHIFT_GSRM2_inputs;  run('<repo>/code/01_SHIFT_GSRM2/SHIFT_GSRM2_model_d_1.m')

# rate and b-value bias on the 0.50 x 0.40 deg grid, 1000 realisations
python3 code/02_rate_and_b_value/bias_metrics.py --stage all --kx 2 --ky 2 --tag 0p50x0p40 --n-cat 1000

# hazard source models, then OpenQuake
python3 code/03_hazard/build_abc_fields.py 1000
python3 code/03_hazard/build_c_fournode_fields.py 1000
python3 code/03_hazard/psha_batch.py --fields 06_psha_source_models --sources truth_kb,A_GK74,GK74_kb_raw --n 1000 --workers 8 --out hazard.csv
```

Requirements: Python 3.10 (numpy, pandas, scipy, h5py, geopandas, shapely), MATLAB R2021a with the Mapping Toolbox, OpenQuake engine 3.25.1.

## External software (not included)

- SHIFT_GSRM2 program of Bird and Kreemer (2015); GSRM v2.1 (Kreemer et al., 2014); PB2002 plate boundaries (Bird, 2003).
- Synthetic catalogues: etas package of L. Mizrahi (Mizrahi et al., 2021).
- OpenQuake engine 3.25.1 (Pagani et al., 2014).
